import 'package:flutter/material.dart';
import 'package:l2_project_pangtehwee/aboutPage.dart';
import 'package:l2_project_pangtehwee/profilePage.dart';
import 'package:l2_project_pangtehwee/review_page.dart';
import 'signupPage.dart';
import 'loginPage.dart';
import 'homePage.dart';
import 'order.dart';
import 'allOrders.dart';
class orderPage extends StatefulWidget {
  orderPage({super.key});

  @override
  State<orderPage> createState() => _orderState();
}

class _orderState extends State<orderPage> {
    int _selectedIndex = 2; 
  int selectedService = 0;
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => homePage()));
        break;
      case 1:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => profilePage()));

        break;
      case 2:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => allOrderPage()));
        break;
      case 3:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => aboutPage()));
        break;
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
            backgroundColor: Color.fromARGB(255, 242, 232, 222),

      body: 
      SafeArea(
        child:Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text('Services Option', style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Wrap(
              spacing: 8, 
              runSpacing: 8, 
              children: <Widget>[
                buildServiceOption(0, 'Fast Delivery (10m)'), 
                buildServiceOption(1, 'Default Delivery (30m)'), 
                buildServiceOption(2, 'Self Pick-up'), 
              ],
            ),
            SizedBox(height: 20),

            Text('Order Summary', style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Expanded( 
              child: ListView.builder(
                itemCount: Order.orderList.length,
                itemBuilder: (context,index){
                  return buildOrderItem(Order.orderList[index][0],Order.orderList[index][1]
                  ,index,Order.orderList[index][2]);
                }
                )
            ),

            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                backgroundColor: Colors.brown[300],
                padding: const EdgeInsets.fromLTRB(35, 25, 35, 25),
              ),
                  onPressed: () {
                          Order.allOrderList.add(Order.orderList);
                          Order.deliveryDate.add(selectedService == 0? "Fast Delivery (10m)":selectedService == 1?"Default Delivery (30m)":"Self Pick-up");
                          print(Order.allOrderList);
                          Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => ReviewPage()));
                  },
                  child: Text('Order Now'),
                ),
              ),
            ),
          ],
        ),
      ),
      ),
    
      bottomNavigationBar:BottomNavigationBar(
        backgroundColor: Colors.brown[300],
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex, 
        selectedItemColor: Colors.brown, 
        unselectedItemColor: Colors.white,
        onTap: _onItemTapped, 
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
          BottomNavigationBarItem(icon: Icon(Icons.shopping_cart), label: 'Order'),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: 'About'),
        ],
      ),
    );
  }
    Widget buildServiceOption(int index, String label) {
    return InkWell(
      onTap: () {
        setState(() {
          
          selectedService = index;
        });
      },
      child: Container(
        padding: EdgeInsets.all(8),
        decoration: BoxDecoration(
          border: Border.all(
            color: selectedService == index ? Colors.blue : Colors.grey,
          ),
          borderRadius: BorderRadius.circular(5),
        ),
        child: Text(label),
      ),
    );
  }
  Widget buildOrderItem(String name, String image, int index, String quantity) {

    return Row(
      children: <Widget>[
        Container(
          width:70,
          height:70,
          margin:EdgeInsets.fromLTRB(0, 0, 5, 0),
          child:Image.asset(image,fit:BoxFit.contain)
        ),
        Expanded(
          
          child: Text(
            name,
            style:TextStyle(
              color:Colors.brown[300],
              fontSize: 16
            ),
          )
          ),
        SizedBox(width: 60),
        Expanded(
          child: Text(
            'x $quantity',
            style:TextStyle(
              color:Colors.brown[300],
              fontSize: 16
            ),
          )
          ),
        IconButton(
          icon: Icon(Icons.delete),
          onPressed: () {
            setState(() {
               Order.orderList.removeAt(index);
            });
          },
        ),
      ],
    );
  }

}