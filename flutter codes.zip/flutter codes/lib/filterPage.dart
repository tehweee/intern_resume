
import 'package:flutter/material.dart';
import 'package:l2_project_pangtehwee/allOrders.dart';
import 'aboutPage.dart';
import 'orderPage.dart';
import 'profilePage.dart';
import 'homePage.dart';
import 'filter.dart';
class filterPage extends StatefulWidget {
  const filterPage({super.key});
  @override
  State<filterPage> createState() => _filterState();
}

class _filterState extends State<filterPage> {
  List<List<String>> cuisineList = [
    ["Hidden Gem", 'icons/gem.jpg'],
    ["Chinese", "icons/chinese.jpg"],
    ["Malay", "icons/malay.png"],
    ["Indian", "icons/indian.jpg"],
    ["Indo", "icons/indo.jpg"],
    ["Turkish", "icons/turkish.jpg"]
  ];

  String? selectedCuisine;  
  List<int> ratings = [5, 4, 3, 2, 1];
  int selectedRating = 0;
  List<String> prices = ['\$\$\$\$\$', '\$\$\$\$', '\$\$\$', '\$\$', '\$'];
  String? selectedPrice; 
  int index = 0;

  void checkTapped(int index) {
    setState(() {
      this.index = index; 
    });
    switch (index) {
      case 0:
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => homePage()));
        break;
      case 1:
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => profilePage()));
        break;
      case 2:
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => allOrderPage()));
        break;
      case 3:
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => aboutPage()));
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 242, 232, 222),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const SizedBox(height: 20),
                const Text('Category',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: cuisineList.map((cuisine) => ChoiceChip( 
                    label: Container(
                      width: 100,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          ClipOval(
                            child: Image.asset(cuisine[1],
                                fit: BoxFit.fill, width: 20, height: 20),
                          ),
                          Text(cuisine[0]),
                        ],
                      ),
                    ),
                    selected: selectedCuisine == cuisine[0], 
                    onSelected: (selected) {
                      setState(() {
                        selectedCuisine = selected ? cuisine[0] : null; 
                      });
                    },
                  )).toList(),
                ),
                const SizedBox(height: 20),
                const Text('Rating',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: ratings.map((ratingRange) => ChoiceChip( 
                    label: Text('⭐ $ratingRange'),
                    selected: selectedRating == ratingRange, 
                    onSelected: (selected) {
                      setState(() {
                        selectedRating = selected ? ratingRange : 5; 
                      });
                    },
                  )).toList(),
                ),
                const SizedBox(height: 20),
                const Text('Price Range',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                Wrap( 
                  spacing: 8,
                  runSpacing: 8,
                  children: prices.map((priceRange) => ChoiceChip( 
                    label: Text(priceRange),
                    selected: selectedPrice == priceRange,
                    onSelected: (selected) {
                      setState(() {
                        selectedPrice = selected ? priceRange : null;  
                      });
                    },
                  )).toList(),
                ),
                Center(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.brown[300],
                      padding: const EdgeInsets.fromLTRB(35, 25, 35, 25),
                    ),
                    onPressed: () {
                      print(selectedCuisine);
                      print(selectedRating);
                      print(selectedPrice);
                      Filter.cuisine = selectedCuisine == null? selectedCuisine = "": selectedCuisine=selectedCuisine;
                      Filter.rating = selectedRating == 0? selectedRating = 5:selectedRating = selectedRating;
                      Filter.price = selectedPrice== null? selectedPrice = "": selectedPrice=selectedPrice;
                      Navigator.pushReplacement(context,
                          MaterialPageRoute(builder: (context) => homePage()));
                    },
                    child: const Text(
                      'Filter',
                      style: TextStyle(color: Colors.white, fontSize: 16),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.brown[300],
        type: BottomNavigationBarType.fixed,
        currentIndex: index,
        selectedItemColor: Colors.brown,
        unselectedItemColor: Colors.white,
        onTap: checkTapped,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(
              icon: Icon(Icons.person), label: 'Profile'),
          BottomNavigationBarItem(
              icon: Icon(Icons.shopping_cart), label: 'Order'),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: 'About'),
        ],
      ),
    );
  }
}