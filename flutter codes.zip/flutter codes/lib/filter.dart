abstract class Filter{
  static String? cuisine = "";
  static int rating = 5;
  static String? price = "";
}

