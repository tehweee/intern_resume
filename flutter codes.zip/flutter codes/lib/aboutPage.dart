import 'package:flutter/material.dart';
import 'package:l2_project_pangtehwee/orderPage.dart';
import 'package:l2_project_pangtehwee/profilePage.dart';
import 'signupPage.dart';
import 'loginPage.dart';
import 'homePage.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:url_launcher/url_launcher.dart';
import 'allOrders.dart';

class aboutPage extends StatefulWidget {
  aboutPage({super.key});

  @override
  State<aboutPage> createState() => _aboutState();
}

class _aboutState extends State<aboutPage> {
  int _selectedIndex = 3; 


  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });


    switch (index) {
      case 0:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => homePage()));
        break;
      case 1:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => profilePage()));
        break;
      case 2:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => allOrderPage()));
        break;
      case 3:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => aboutPage()));
        break;
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
            backgroundColor: Color.fromARGB(255, 242, 232, 222),
      appBar: AppBar(
        backgroundColor: Colors.brown[300],
        title: Text('About Us', style: TextStyle(color: Colors.white)),
        elevation: 0,
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Container(
              
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
              ),
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              child: Image.asset("logos/logo.png",fit:BoxFit.contain),
            ),
          ),
        ],
      ),
      body:Center(
          child: SizedBox(
            width: 300,
            child: SingleChildScrollView(
            child:Column(
              children: <Widget>[
                Container(
                  height: 130,
                  margin: const EdgeInsets.only(bottom: 20),
                  child: Image.asset("logos/logo_text.png",fit: BoxFit.contain)
                ),
                const Text(
                  'What are we here to do?',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                const Text(
                  'Ancient Corner is a delivery app designed to help older hawker owners bring their delicious traditional dishes to more customers. By providing a simple and accessible platform, it allows them to expand their reach and increase revenue without the need for complex technology.',
                  style: TextStyle(fontSize: 16),
                ),
                const SizedBox(height: 30),

                                Container(
                  height: 300,
                  margin: const EdgeInsets.only(bottom: 20),
                  child: Image.asset("icons/about1.jpg",fit: BoxFit.contain)
                ),
                const Text(
                  'Empowering Older Hawkers with Technology',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                const Text(
                  'Many elderly hawkers struggle with modern digital platforms. Ancient Corner makes it easy for them to adopt technology, offering a user-friendly interface that helps them manage orders effortlessly, ensuring their businesses thrive in the digital economy.',
                  style: TextStyle(fontSize: 16),
                ),
                const SizedBox(height: 30),
                                Container(
                  height: 300,
                  margin: const EdgeInsets.only(bottom: 20),
                  child: Image.asset("icons/about2.jpg",fit: BoxFit.cover)
                ),
                const Text(
                  'Discover and Preserve Food Heritage',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                const Text(
                  'Users can explore and enjoy authentic, time-honored hawker dishes through the app, supporting small businesses while preserving the rich culinary heritage of traditional street food culture for future generations.',
                  style: TextStyle(fontSize: 16),
                ),
                const SizedBox(height: 30),
                const Text(
                  'Customer Support Info',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                const Text('Support No. - 1234 5678'),
                const SizedBox(height: 5),
                const Text('Support Email. - acientcorner@gmail.com'),
                const SizedBox(height: 30),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children:[
                    ElevatedButton(
                style: ElevatedButton.styleFrom(
                backgroundColor: Colors.brown[300],
                padding: const EdgeInsets.fromLTRB(35, 25, 35, 25),
                ),
                  onPressed: () {
                      FlutterPhoneDirectCaller.callNumber('+6512345678');

                  },
                  child: const Text('Contact Us'),
                ),
                ElevatedButton(
                style: ElevatedButton.styleFrom(
                backgroundColor: Colors.brown[300],
                padding: const EdgeInsets.fromLTRB(35, 25, 35, 25),
                ),
                  onPressed: () async{
                   String? encodeQueryParameters(Map<String, String> params) {
                    return params.entries
                        .map((MapEntry<String, String> e) =>
                            '${Uri.encodeComponent(e.key)}=${Uri.encodeComponent(e.value)}')
                        .join('&');
                  }
    
                    final Uri emailLaunchUri = Uri(
                      scheme: 'mailto',
                      path: 'acientcorner@example.com',
                      query: encodeQueryParameters(<String, String>{
                        'subject': 'Hello there Acient Corner',
                        'body': 'Write Something to Acent Corner'
                      }),
                    );
                    if(await canLaunchUrl(emailLaunchUri)){
                      launchUrl(emailLaunchUri);

                    }else{
                      throw Exception('Could not launch $emailLaunchUri');
                    }

                  },
                  child: const Text('Email Us'),
                ),
                  ]
                ),
                const SizedBox(height: 40),

              ],
            ),
            ),
         
          ),
        ),
      
      bottomNavigationBar:BottomNavigationBar(
        backgroundColor: Colors.brown[300],
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex, 
        selectedItemColor: Colors.brown, 
        unselectedItemColor: Colors.white,
        onTap: _onItemTapped,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
          BottomNavigationBarItem(icon: Icon(Icons.shopping_cart), label: 'Order'),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: 'About'),
        ],
      ),
    );
  }
}