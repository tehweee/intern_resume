import 'package:flutter/material.dart';
import 'package:l2_project_pangtehwee/restaurentPage.dart';
import 'signupPage.dart';
import 'loginPage.dart';
import 'main.dart';
import 'profilePage.dart';
import 'orderPage.dart';
import 'aboutPage.dart';
import 'filterPage.dart';
import 'confirmOrder.dart';
import 'review_page.dart';
import 'global.dart';
import 'filter.dart';
import 'allOrders.dart';

class homePage extends StatefulWidget {
  const homePage({super.key});

  @override
  State<homePage> createState() => _homeState();
}

class _homeState extends State<homePage> {
  List<String> restaurentNames = ["Spice Route Delights","Bella Luna Trattoria","Tokyo Fusion Kitchen","Saigon Street Food","The Cozy Bistro"];
  List<String> restaurentImages= ['icons/res1.jpg','icons/res2.png','icons/res3.jpg','icons/res4.jpg','icons/res5.png'];
  List<String> prices = ["\$","\$\$","\$\$\$","\$\$\$","\$\$"];
  List<String> deliveryFees = ["2","1","3","4","5"];
  List<String> deliveryTimes = ["20","30","12","31","41"];
  List<String> cusines = ["Malay","Indian","Indo","Turkish","Chinese"];
  List<double> ratings = [4.2,2.1,4.1,5,1.1];
  String filterResName = "";
  String? filterResCuisine = Filter.cuisine;
  int filterResRating = Filter.rating;
  String? filterResPrice = Filter.price;

  bool starterToggle = true;
  int index = 0; 

  void updateFilterResName(String value){
    setState(() {
      filterResName = value;
    });
  }
  void updateFilterResCusine(){
    setState(() {
      filterResCuisine = Filter.cuisine;
    });
  }
  void checkTapped(int index) {
    setState(() {
      index = index;
    });

    switch (index) {
      case 0:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => homePage()));
        break;
      case 1:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => profilePage()));
        break;
      case 2:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => allOrderPage()));
        break;
      case 3:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => aboutPage()));
        break;
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
            backgroundColor: Color.fromARGB(255, 242, 232, 222),

      body:
      SafeArea(
        child: Column(
          
          children: [
            Padding(
              padding:  EdgeInsets.all(8),
              child: TextField(
                onSubmitted: (value){
                  updateFilterResName(value);
                },
                decoration: const InputDecoration(
                  hintText: 'Search by Restaurent Name',
                        enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.brown,width: 2),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Color.fromARGB(255, 232, 164, 139), width: 2),
                      ),
                ),
              ),
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child:            
              Row(
                children: [
                  _buildCategory('Hidden Gem','icons/gem.jpg'),
                  _buildCategory('Chinese','icons/chinese.jpg'),
                  _buildCategory('Malay','icons/malay.png'),
                  _buildCategory('Indian','icons/indian.jpg'),
                  _buildCategory('Indo','icons/indo.jpg'),
                  _buildCategory('Turkish','icons/turkish.jpg'),
                ],
              ),
            ),
            Container(
              margin:EdgeInsets.fromLTRB(0, 20, 0, 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children:[
              Container(
                margin: EdgeInsets.fromLTRB(10, 0, 10, 0),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.brown[300],
                      padding: const EdgeInsets.fromLTRB(35, 25, 35, 25),
                      ),
                    onPressed: () {
                      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>filterPage()));
                    },
                    child: Text('Filter'),
                  ),
                ),
              ),
                          Container(
                            margin: EdgeInsets.fromLTRB(10, 0, 10, 0),
                            child: Padding(
                                        padding: const EdgeInsets.symmetric(vertical: 8),
                                        child: ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                            backgroundColor: Colors.brown[300],
                                            padding: const EdgeInsets.fromLTRB(35, 25, 35, 25),
                                            ),
                                          onPressed: () {
                                            setState(() {
                                              Filter.cuisine = "";
                                              Filter.rating = 5;
                                              Filter.price = "";
                                              filterResName = "";
                                              filterResCuisine = Filter.cuisine;
                                              filterResRating = Filter.rating;
                                              filterResPrice = Filter.price;

                                            });
                                          },
                                          child: Text('Reset'),
                                        ),
                                      ),
                          ),
                ]
              ),
            ),
            
            Expanded(
              child:ListView.builder(
                itemCount: prices.length,
                  itemBuilder: (context,index){
                  return _buildRestaurantCard(restaurentNames[index], ratings[index],cusines[index], 
                  prices[index], deliveryFees[index], deliveryTimes[index], restaurentImages[index]);
                  
                }, 
                )
            )
          ],
        ),

      
      ),
      

      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.brown[300],
        type: BottomNavigationBarType.fixed,
        currentIndex: index, 
        selectedItemColor: Colors.brown, 
        unselectedItemColor: Colors.white,
        onTap: checkTapped, 
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
          BottomNavigationBarItem(icon: Icon(Icons.shopping_cart), label: 'Order'),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: 'About'),
        ],
      ),
    );
  }

  Widget _buildCategory(String name,String image) {
    return ElevatedButton(
        onPressed: (){
          Filter.cuisine = name;
          updateFilterResCusine();
        } ,
          style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent, 
          elevation: 0, 
        ),
        child: Column(
        children: [
          CircleAvatar(
            radius: 20, 
            backgroundImage: AssetImage(image),
            ),
          Text(name,style: TextStyle(color:Colors.black)),
        ],
      ),
        );
    
  }

  Widget _buildRestaurantCard(String restaurentName
  ,double starRating,String cuisine,String price,String deliveryFee,
  String deliveryTime,String restaurentImage) {
    return (filterResName.length == 0 && filterResCuisine!.isEmpty && filterResPrice!.isEmpty) || (filterResName.contains(restaurentName) 
    || (filterResCuisine == cuisine) || (filterResPrice == price))? (Filter.rating.toDouble() >= starRating)?Container(
      width:300,
      child:ElevatedButton(
                  style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent, 
          shadowColor: Colors.transparent, 
          
          elevation: 0, 
        ),
        onPressed: (){
                                  print(Filter.rating);
                                  print(starRating);
                                  print(filterResCuisine);
                                  print(cuisine);
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => restaurentPage(restaurantName: restaurentName,restaurantRating: 
        '$starRating',restaurentImage: restaurentImage,)));

        },
         child: Padding(
        padding: const EdgeInsets.all(2),
        child: Row(
          children: [
            Container(
              width: 100,
              height: 100,
              margin: EdgeInsets.fromLTRB(0, 0, 30, 0),
              child:Image.asset(restaurentImage,fit: BoxFit.contain), 
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(restaurentName, style: TextStyle(fontWeight: FontWeight.w600,fontSize:20,color:Colors.black)),
                Text('⭐ ${starRating}  ${cuisine} Cuisine',style: TextStyle(fontWeight: FontWeight.w400,fontSize:15,color:Colors.black)),
                Text('Price: ${price}',style: TextStyle(fontWeight: FontWeight.w400,fontSize:15,color:Colors.black)),
                Text('Delivery \$ ${deliveryFee} in ${deliveryTime} mins',style: TextStyle(fontWeight: FontWeight.w400,fontSize:15,color:Colors.black)),
              ],
            ),
          ],
        ),
      ),
        ),
     
    ):SizedBox():SizedBox();
  }
}
