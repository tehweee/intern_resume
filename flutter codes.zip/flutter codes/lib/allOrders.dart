import 'package:flutter/material.dart';
import 'package:l2_project_pangtehwee/aboutPage.dart';
import 'package:l2_project_pangtehwee/profilePage.dart';
import 'package:l2_project_pangtehwee/review_page.dart';
import 'signupPage.dart';
import 'loginPage.dart';
import 'homePage.dart';
import 'order.dart';
import 'orderPage.dart';


class allOrderPage extends StatefulWidget {
  allOrderPage({super.key});

  @override
  State<allOrderPage> createState() => _listorderState();
}

class _listorderState extends State<allOrderPage> {
  int _selectedIndex = 2;
  int selectedService = 0;
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => homePage()));
        break;
      case 1:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => profilePage()));
        break;
      case 2:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => allOrderPage()));
        break;
      case 3:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => aboutPage()));
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    Order.orderList = [];
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 242, 232, 222),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Container(
              padding:EdgeInsets.all(8),
              margin:EdgeInsets.fromLTRB(0, 5, 0, 5),
          decoration: BoxDecoration(
            color:Colors.white,
            border: Border.all(
              color:Colors.brown,
              width: 2,
            ),
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color:Colors.brown.withOpacity(0.6),
                spreadRadius:5,
                blurRadius: 7,
                offset: Offset(0,3)
              )
            ]
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Text('Order Summary',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
                SizedBox(height: 10),
                Expanded(
                  child: ListView.builder(
                    itemCount: Order.allOrderList.length,
                    itemBuilder: (context, index) {
                      return buildShowOrderItem(Order.allOrderList[index],index+1);
                    },
                  ),
                
                ),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.brown[300],
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.brown,
        unselectedItemColor: Colors.white,
        onTap: _onItemTapped,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
          BottomNavigationBarItem(icon: Icon(Icons.shopping_cart), label: 'Order'),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: 'About'),
        ],
      ),
    );
  }

  Widget buildShowOrderItem(List<List<String>> list,int orderPosition) {
    return Container(
      
      margin: EdgeInsets.fromLTRB(0, 0, 10, 10),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Order Id: $orderPosition'),
              Text(Order.deliveryDate[orderPosition-1]),
            ],
          ),
          Column( 
        children: List.generate(list.length, (index) {
          return buildMoreOrderItem(list[index][0], list[index][1], index, list[index][2]);
        }),
      ),
        ],
      ),
    );
  }


  Widget buildMoreOrderItem(String name, String image, int index, String quantity) {
    return 
            Container(
              padding:EdgeInsets.all(8),
              margin:EdgeInsets.fromLTRB(0, 5, 0, 5),
          decoration: BoxDecoration(
            color:Colors.white,
            border: Border.all(
              color:Colors.brown,
              width: 2,
            ),
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color:Colors.brown.withOpacity(0.6),
                spreadRadius:5,
                blurRadius: 7,
                offset: Offset(0,3)
              )
            ]
            ),
            child:Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
                Container(
                  width: 70,
                  height: 70,
                  margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                  child: Image.asset(image, fit: BoxFit.contain),
                ),
                Text(
                  name,
                  style: TextStyle(
                    color: Colors.brown[300],
                    fontSize: 16,
          ),
        ),
            ],
          
        ),
        Text(
          'x $quantity',
          style: TextStyle(
            color: Colors.brown[300],
            fontSize: 16,
          ),
        ),
      ],
    )
            );
  }
}