// import 'package:flutter/material.dart';



// class confirmOrderPage extends StatefulWidget {
//   @override
//   _confirmOrderState createState() => _confirmOrderState();
// }

// class _confirmOrderState extends State<confirmOrderPage> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Custom Order'),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: <Widget>[
//             // Food Item Display
//             Expanded(
//               child: ListView.builder(
//                 itemCount: 3, // Replace with your actual item count
//                 itemBuilder: (context, index) {
//                   return Card(
//                     child: ListTile(
//                       leading: Container( // Placeholder for image
//                         width: 50,
//                         height: 50,
//                         color: Colors.grey[300], // Light grey placeholder
//                       ),
//                       title: Text('Food Name'), // Replace with actual name
//                       subtitle: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Text('\$Price'), // Replace with actual price
//                           Text('Description...'), // Replace with actual description
//                         ],
//                       ),
//                     ),
//                   );
//                 },
//               ),
//             ),

//             SizedBox(height: 20),

//             // Customized Order List
//             Text('Custom Order', style: TextStyle(fontWeight: FontWeight.bold)),
//             Expanded(
//               child: ListView.builder(
//                 itemCount: 5, // Replace with your actual item count
//                 itemBuilder: (context, index) {
//                   return ListTile(
//                     title: Text('Customized Order'), // Replace with actual order info
//                     trailing: IconButton(
//                       icon: Icon(Icons.delete),
//                       onPressed: () {
                        
//                       },
//                     ),
//                   );
//                 },
//               ),
//             ),

//             // Add to Custom Order Button
//             Center(
//               child: ElevatedButton(
//                 onPressed: () {
//                   // Handle add to order logic here
//                 },
//                 child: Text('Add to Custom Order'),
//               ),
//             ),

//             SizedBox(height: 20),

//             // Confirm and Cancel Buttons
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceAround,
//               children: [
//                 ElevatedButton(
//                   onPressed: () {
//                     // Handle cancel logic here
//                   },
//                   child: Text('Cancel'),
//                 ),
//                 ElevatedButton(
//                   onPressed: () {
//                     // Handle confirm logic here
//                   },
//                   child: Text('Confirm'),
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//       bottomNavigationBar: BottomNavigationBar(
//         items: const <BottomNavigationBarItem>[
//           BottomNavigationBarItem(
//             icon: Icon(Icons.home),
//             label: 'Home',
//           ),
//           BottomNavigationBarItem(
//             icon: Icon(Icons.person),
//             label: 'Profile',
//           ),
//           BottomNavigationBarItem(
//             icon: Icon(Icons.shopping_cart),
//             label: 'Order',
//           ),
//           BottomNavigationBarItem(
//             icon: Icon(Icons.info),
//             label: 'About',
//           ),
//         ],
//         currentIndex: 0,
//         onTap: (int index) {
//           // Handle navigation here
//         },
//       ),
//     );
//   }
// }