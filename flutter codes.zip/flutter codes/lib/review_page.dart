import 'package:flutter/material.dart';
import 'package:l2_project_pangtehwee/aboutPage.dart';
import 'package:l2_project_pangtehwee/profilePage.dart';
import 'package:l2_project_pangtehwee/review_page.dart';
import 'signupPage.dart';
import 'loginPage.dart';
import 'homePage.dart';
import 'orderPage.dart';
import 'order.dart';
import 'allOrders.dart';
class ReviewPage extends StatefulWidget {


  ReviewPage({super.key});

  @override
  State<ReviewPage> createState() => _ReviewPageState();
}

class _ReviewPageState extends State<ReviewPage> {
  int _selectedIndex = 2; 
  int rating = 0;
  String reviewText = '';
void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => homePage()));
        break;
      case 1:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => profilePage()));
        break;
      case 2:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => allOrderPage()));
        break;
      case 3:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => aboutPage()));
        break;
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
                  backgroundColor: Color.fromARGB(255, 242, 232, 222),

          body: SafeArea( 

      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Expanded(
            child:ListView.builder(
                itemCount: Order.orderList.length,
                itemBuilder: (context,index){
                  return buildOrderItem(Order.orderList[index][0],Order.orderList[index][1],index,Order.orderList[index][2]);
                }),
            ),   
            SizedBox(height: 20),

            Row(
              children: List.generate(5, (index) {
                return IconButton(
                  icon: Icon(
                    index < rating ? Icons.star : Icons.star_border,
                    color: Colors.amber,
                  ),
                  onPressed: () {
                    setState(() {
                      rating = index + 1;
                    });
                  },
                );
              }),
            ),

            SizedBox(height: 20),

            Text('Write a Review', style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            TextField(
              maxLines: 5,
              decoration: InputDecoration(
                hintText: 'Enter your review here...',
                border: OutlineInputBorder(),
              ),
              onChanged: (text) {
                reviewText = text;
              },
            ),

            SizedBox(height: 20),

            Center(
              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                backgroundColor: Colors.brown[300],
                padding: const EdgeInsets.fromLTRB(35, 25, 35, 25),
              ),
                onPressed: () {
                  print(Order.orderList);
                  if (!(rating == 0 || reviewText.isEmpty)) {
                    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => allOrderPage()));

                  }
                },
                child: Text('Submit Now'),
              ),
            ),
          ],
        ),
      ),
          ),
                bottomNavigationBar:BottomNavigationBar(
        backgroundColor: Colors.brown[300],
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex, 
        selectedItemColor: Colors.brown,
        unselectedItemColor: Colors.white,
        onTap: _onItemTapped, 
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
          BottomNavigationBarItem(icon: Icon(Icons.shopping_cart), label: 'Order'),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: 'About'),
        ],
      ),
    );
  }
  Widget buildOrderItem(String name, String image, int index, String quantity) {
    print(name);
    return Row(
      children: <Widget>[
        Container(
          width:70,
          height:70,
          margin:EdgeInsets.fromLTRB(0, 0, 5, 0),
          child:Image.asset(image,fit:BoxFit.contain)
        ),
        Expanded(
          
          child: Text(
            name,
            style:TextStyle(
              color:Colors.brown[300],
              fontSize: 16
            ),
          )
          ),
        SizedBox(width: 60),
        Expanded(
          child: Text(
            'x $quantity',
            style:TextStyle(
              color:Colors.brown[300],
              fontSize: 16
            ),
          )
          ),
        IconButton(
          icon: Icon(Icons.delete),
          onPressed: () {
            setState(() {
               Order.orderList.removeAt(index);
            });
          },
        ),
      ],
    );
  }
}