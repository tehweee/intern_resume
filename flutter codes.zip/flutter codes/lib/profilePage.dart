import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:l2_project_pangtehwee/aboutPage.dart';
import 'package:l2_project_pangtehwee/allOrders.dart';
import 'package:l2_project_pangtehwee/editProfile.dart';
import 'package:l2_project_pangtehwee/orderPage.dart';
import 'signupPage.dart';
import 'loginPage.dart';
import 'homePage.dart';
import 'global.dart';
import 'package:image_picker/image_picker.dart';


class profilePage extends StatefulWidget {
  profilePage({super.key});

  @override
  State<profilePage> createState() => _profileState();
}

class _profileState extends State<profilePage> {
    int _selectedIndex = 1;
    void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => homePage()));
        break;
      case 1:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => profilePage()));
        break;
      case 2:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => allOrderPage()));
        break;
      case 3:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => aboutPage()));
        break;
    }
  }
  File? _selectedImage = Profile.selectedImage;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 242, 232, 222),
      appBar: AppBar(
        backgroundColor: Colors.brown[300],
        title: Text('Edit Profile', style: TextStyle(color: Colors.white)),
        elevation: 0,
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Container(
              
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
              ),
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              child: Image.asset("logos/logo.png",fit:BoxFit.contain),
            ),
          ),
        ],
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
                CircleAvatar(
          radius: 50,
          backgroundImage: _selectedImage != null
              ? FileImage(_selectedImage!) 
              : const AssetImage("icons/guest.jpg") as ImageProvider, 
        ),
                    ElevatedButton(
            onPressed: () {
              _pickImageFromGallery();
            },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.brown[300],
                padding: const EdgeInsets.fromLTRB(35, 25, 35, 25),
              ),
              child: const Text(
                'Edit Picture',
                style: TextStyle(color: Colors.white, fontSize: 16),
              ),          ),
            ],
          ),
        
          SizedBox(height: 60),

          _buildProfileText('Name', '${Profile.name}'),
          _buildProfileText('Email', '${Profile.email}'),
          _buildProfileText('Phone No', '${Profile.hp}'),
          _buildProfileText('Password', '${Profile.password}'),

          SizedBox(height: 60),
          ElevatedButton(
            onPressed: () {
                    Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => editProfilePage()),
      );
            },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.brown[300],
                padding: const EdgeInsets.fromLTRB(35, 25, 35, 25),
              ),
              child: const Text(
                'Edit Profile',
                style: TextStyle(color: Colors.white, fontSize: 16),
              ),          
              ),
        ],
      ),

      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.brown[300],
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex, 
        selectedItemColor: Colors.brown, 
        unselectedItemColor: Colors.white,
        onTap: _onItemTapped, 
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
          BottomNavigationBarItem(icon: Icon(Icons.shopping_cart), label: 'Order'),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: 'About'),
        ],
      ),
    );
  }

  Widget _buildProfileText(String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 6, horizontal: 20),
      child: Align(
        alignment: Alignment.centerLeft,
        child: RichText(
          text: TextSpan(
            text: '$label: ',
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 16),
            children: [
              TextSpan(
                text: value,
                style: TextStyle(fontWeight: FontWeight.normal),
              ),
            ],
          ),
        ),
      ),
    );
  }
  Future _pickImageFromGallery() async {
    final returnedImage = await ImagePicker().pickImage(source:ImageSource.gallery);
    if(returnedImage == null){
      return;
    }else{
    setState(() {
      Profile.selectedImage = File(returnedImage!.path);
      _selectedImage = File(returnedImage!.path);
    });
    }
  }
}