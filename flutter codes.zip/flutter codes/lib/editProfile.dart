import 'package:flutter/material.dart';
import 'package:l2_project_pangtehwee/profilePage.dart';
import 'homePage.dart';
import 'global.dart';

class editProfilePage extends StatefulWidget {
  const editProfilePage({super.key});

  @override
  State<editProfilePage> createState() => _editProfileState();
}

class _editProfileState extends State<editProfilePage> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController hpController = TextEditingController();
  final TextEditingController pwdController = TextEditingController();

  String? nameError;
  String? emailError;
  String? phoneError;
  String? passwordError;

  void _edit() {
    setState(() {
      nameError = _validateUsername(nameController.text);
      emailError = _validateEmail(emailController.text);
      phoneError = _validatePhone(hpController.text);
      passwordError = _validatePassword(pwdController.text);
    });

    if (nameError == null &&
        emailError == null &&
        phoneError == null &&
        passwordError == null) {
      Profile.name = nameController.text;
      Profile.email = emailController.text;
      Profile.hp = hpController.text;
      Profile.password = pwdController.text;
      Navigator.push(context, MaterialPageRoute(builder: (context) => profilePage()));
    }
  }

  String? _validateUsername(String value) {
    if(value.isEmpty) {
      return "Please enter your username";
      }
    if(value.length < 3) {
      return "Username must be at least 3 characters long";
      }
    return null;
  }

  String? _validateEmail(String value) {
    if (value.isEmpty) {
      return "Please enter your email";
      }
    final emailRegex = RegExp(r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$');
    if (!emailRegex.hasMatch(value)) {
      return "Enter a valid email address";}
    return null;
  }

  String? _validatePhone(String value) {
    if (value.isEmpty) {
      return "Please enter your phone number";}
    if (!RegExp(r'^\d{8}$').hasMatch(value)) {
      return "Phone number must be exactly 8 digits";
      }
    return null;
  }

  String? _validatePassword(String value) {
    if (value.isEmpty) {
      return "Please enter a password";
      }
    if (value.length < 8){ 
      return "Password must be at least 8 characters long";
      }
    if (!RegExp(r'^(?=.*[A-Z])').hasMatch(value)) {
      return "Must contain at least one uppercase letter";}
    if (!RegExp(r'^(?=.*[a-z])').hasMatch(value)) {return "Must contain at least one lowercase letter";
    }
    if (!RegExp(r'^(?=.*\d)').hasMatch(value)) {
      return "Must contain at least one number";
      }
    if (!RegExp(r'^(?=.*[@$!%*?&])').hasMatch(value)) {
      return "Must contain at least one special character";
      }
    return null;
  }

  String? _validateConfirmPassword(String value) {
    if (value.isEmpty) {
      return "Please confirm your password";
      }
    if (value != pwdController.text) {
      return "Passwords do not match";
      }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 242, 232, 222),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.asset("logos/logo_text.png"),
              const SizedBox(height: 30),
              const Text("Edit Profile Info", style: TextStyle(fontSize: 30, fontWeight: FontWeight.w300)),
              const SizedBox(height: 20),

              TextField(
                controller: nameController,
                decoration: InputDecoration(
                  labelText: 'Name:',
                  
                                        labelStyle: const TextStyle(color: Colors.brown),
                      enabledBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.brown, width: 2),
                      ),
                      focusedBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: Color.fromARGB(255, 232, 164, 139), width: 2),
                      ),
                  errorText: nameError,
                ),
              ),
              const SizedBox(height: 15),

              TextField(
                controller: emailController,
                decoration: InputDecoration(
                  labelText: 'Email:',
                                        labelStyle: const TextStyle(color: Colors.brown),
                      enabledBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.brown, width: 2),
                      ),
                      focusedBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: Color.fromARGB(255, 232, 164, 139), width: 2),
                      ),
                  errorText: emailError,
                ),
              ),
              const SizedBox(height: 15),

              TextField(
                controller: hpController,
                decoration: InputDecoration(
                  labelText: 'Phone No:',
                  labelStyle: const TextStyle(color: Colors.brown),
                  errorText: phoneError,
                ),
              ),
              const SizedBox(height: 15),

              TextField(
                controller: pwdController,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'Password:',
                  labelStyle: const TextStyle(color: Colors.brown),
                  errorText: passwordError,
                ),
              ),
              const SizedBox(height: 25),

              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.brown[300],
                  padding: const EdgeInsets.symmetric(horizontal: 35, vertical: 20),
                ),
                onPressed: _edit,
                child: const Text('Signup', style: TextStyle(color: Colors.white, fontSize: 16)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
