import 'package:flutter/material.dart';
import 'package:l2_project_pangtehwee/confirmOrder.dart';
import 'package:l2_project_pangtehwee/filterPage.dart';
import 'signupPage.dart';
import 'loginPage.dart';
import 'homePage.dart';
import 'review_page.dart';
import 'restaurentPage.dart';
import 'orderPage.dart';
import 'allOrders.dart';
void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Default Template',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LoginPage(),
    );
  }
}





