import 'package:flutter/material.dart';
import 'main.dart';
import 'signupPage.dart';
import 'homePage.dart';
import 'global.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginState();
}

class _LoginState extends State<LoginPage> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController pwdController = TextEditingController();
  
  String? _usernameError;
  String? _passwordError;

  String? _validateUsername(String value) {
    if (value.isEmpty) {
      return "Please enter your username";
    } else if (value.length < 3) {
      return "Username must be at least 3 characters";
    } else if(Profile.name != value){
      return "Incorrect username being entered";
    }
    return null;
  }

  String? _validatePassword(String value) {
    if (value.isEmpty) {
      return "Please enter your password";
    } else if (value.length < 6) {
      return "Password must be at least 6 characters long";
    } else if (!RegExp(r'^(?=.*[A-Z])').hasMatch(value)) {
      return "Password must contain at least one uppercase letter";
    } else if (!RegExp(r'^(?=.*[a-z])').hasMatch(value)) {
      return "Password must contain at least one lowercase letter";
    } else if (!RegExp(r'^(?=.*\d)').hasMatch(value)) {
      return "Password must contain at least one number";
    } else if (!RegExp(r'^(?=.*[@$!%*?&])').hasMatch(value)) {
      return "Password must contain at least one special character";
    } else if (Profile.password != value){
      return "Incorrect password";
    }
    return null;
  }

  void _login() {
    String? usernameError = _validateUsername(nameController.text);
    String? passwordError = _validatePassword(pwdController.text);

    setState(() {
      _usernameError = usernameError;
      _passwordError = passwordError;
    });

    if (usernameError == null && passwordError == null) {
      Profile.name = nameController.text;
      Profile.password = pwdController.text;

      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => homePage()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 242, 232, 222),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.asset("logos/logo_text.png"),
              const SizedBox(height: 90),
              const Text(
                "Login",
                style: TextStyle(fontSize: 30, fontWeight: FontWeight.w300),
              ),
              const SizedBox(height: 30),
              
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: SizedBox(
                  height: 50,
                  child: TextField(
                    controller: nameController,
                    decoration: InputDecoration(
                      labelText: 'Username:',
                      labelStyle: const TextStyle(color: Colors.brown),
                      enabledBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.brown, width: 2),
                      ),
                      focusedBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: Color.fromARGB(255, 232, 164, 139), width: 2.0),
                      ),
                      errorText: _usernameError, 
                    ),
                  ),
                ),
              ),
              
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: SizedBox(
                  height: 50,
                  child: TextField(
                    controller: pwdController,
                    obscureText: true,
                    decoration: InputDecoration(
                      labelText: 'Password:',
                      labelStyle: const TextStyle(color: Colors.brown),
                      enabledBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.brown, width: 2),
                      ),
                      focusedBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: Color.fromARGB(255, 232, 164, 139), width: 2.0),
                      ),
                      errorText: _passwordError, 
                    ),
                  ),
                ),
              ),
              
              const SizedBox(height: 20),
              
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => SignupPage()),
                  );
                },
                child: const Text(
                  'Go to Register Page',
                  style: TextStyle(
                    color: Colors.brown,
                    decoration: TextDecoration.underline,
                  ),
                ),
              ),
              
              const SizedBox(height: 25),
              
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.brown[300],
                  padding: const EdgeInsets.fromLTRB(35, 25, 35, 25),
                ),
                onPressed: _login,
                child: const Text(
                  'Login',
                  style: TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
