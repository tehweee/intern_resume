import 'package:flutter/material.dart';
import 'package:l2_project_pangtehwee/aboutPage.dart';
import 'package:l2_project_pangtehwee/allOrders.dart';
import 'package:l2_project_pangtehwee/profilePage.dart';
import 'package:l2_project_pangtehwee/review_page.dart';
import 'signupPage.dart';
import 'loginPage.dart';
import 'homePage.dart';
import 'orderPage.dart';
import 'order.dart';

class restaurentPage extends StatefulWidget {
  String restaurantName;
    String restaurantRating;
    String restaurentImage;

  restaurentPage({super.key,required this.restaurantName,required this.restaurantRating,required this.restaurentImage});

  List<String> setup(){
    Map<String, List<String>> restaurantMenu = {
    'Spice Route Delights': [
      'Lamb Vindaloo, Spicy tender lamb curry, 4.5,icons/lamb_vindaloo.jpg',
      'Butter Chicken, Creamy tomato sauce chicken, 4.7,icons/butter_chicken.jpg',
      'Paneer Tikka, Grilled marinated cottage cheese, 4.3,icons/paneer_tikka.jpg',
    ],
    'Bella Luna Trattoria': [
      'Margherita Pizza, Classic tomato basil mozzarella, 4.8,icons/margherita_pizza.jpg',
      'Spaghetti Carbonara, Creamy pasta with pancetta, 4.6,icons/spaghetti_carbonara.jpg',
      'Lasagna Bolognese, Rich cheesy meat lasagna, 4.7,icons/lasagna_bolognese.jpg',
    ],
    'Tokyo Fusion Kitchen': [
      'Sushi Platter, Fresh assorted sushi selection, 4.9,icons/sushi_platter.png',
      'Ramen Noodles, Flavorful broth with toppings, 4.8,icons/ramen_noodles.jpg',
      'Teriyaki Chicken, Sweet soy glazed chicken, 4.6,icons/teriyaki_chicken.jpg',
    ],
    'Saigon Street Food': [
      'Pho Bo, Beef noodle soup with herbs, 4.7,icons/pho_bo.jpg',
      'Bánh Mì, Vietnamese sandwich with pork, 4.6,icons/banh_mi.jpg',
      'Com tam (Broken Rice), Grilled pork with rice, 4.5,icons/com_tam.jpg',
    ],
    'The Cozy Bistro': [
      'Chicken Alfredo, Creamy pasta with grilled chicken, 4.7,icons/chicken_alfredo.jpg',
      'Beef Wellington, Tender beef wrapped in pastry, 4.8,icons/beef_wellington.jpg',
      'Vegetable Risotto, Creamy rice with seasonal veggies, 4.6,icons/vegetable_risotto.jpg',
    ],
  };
  return restaurantMenu[this.restaurantName]!;
  }

  @override
  State<restaurentPage> createState() => _resState();
}

class _resState extends State<restaurentPage> {
    int _selectedIndex = 2; 
void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => homePage()));
        break;
      case 1:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => profilePage()));

        break;
      case 2:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => allOrderPage()));
        break;
      case 3:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => aboutPage()));
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
                  backgroundColor: Color.fromARGB(255, 242, 232, 222),
      body: 
      SafeArea(
  child:Padding( 
        padding: const EdgeInsets.all(3),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
              Container(
              width:70,
              height:70,
              child: Image.asset(widget.restaurentImage,fit:BoxFit.contain)
              ),
              SizedBox(width:20),
            Text(widget.restaurantName,style:TextStyle(fontSize:30,fontWeight:FontWeight.w300)),
                          SizedBox(height:30),

              ],
            ),
            
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text('Location',style:TextStyle(fontWeight:FontWeight.w300)),

                Row(
                  children: <Widget>[
                    Icon(Icons.star, color: Colors.amber), 
                    Text(widget.restaurantRating,style:TextStyle(fontWeight:FontWeight.w300)), 
                  ],
                ),
                Text('123 Reviews',style:TextStyle(fontWeight:FontWeight.w300)), 
              ],
            ),

            SizedBox(height: 20),

            Text('Main Course', style: TextStyle(fontWeight: FontWeight.bold)),
            Expanded(
              child:ListView.builder(
                itemCount: widget.setup().length,
                itemBuilder: (context,index){
                  final meal =  widget.setup()[index];
                  final parts = meal.split(",");
                    return ElevatedButton(
                      style: ElevatedButton.styleFrom(
                      backgroundColor: Color.fromARGB(255, 242, 232, 222),
                      ),
                      onPressed: (){
                        print(Order.orderList.length);
                        bool toggle = true;
                        if(Order.orderList.length != 0){
                        for(int i = 0; i < Order.orderList.length;i++){
                            if(Order.orderList[i][0] == parts[0]){
                              int updated = int.parse(Order.orderList[i][2]) + 1;
                              Order.orderList[i] = ([parts[0],parts[3],'$updated']);
                              toggle = false;
                              break;
                          }
                          }
                        }else{
                            Order.orderList.add([parts[0],parts[3],'1']);
                            toggle = false;
                            print("Added");
                          }
                          if(toggle){
                            Order.orderList.add([parts[0],parts[3],'1']);
                            print("Added");
                          }
                        for(int i = 0; i < Order.orderList.length;i++){
                          List<String> currentRow = Order.orderList[i];
                          String currentRow1 = currentRow[0];
                          String currentRow2 = currentRow[1];
                          String currentRow3 = currentRow[2];
                          print('LIST OF CONTENT PART: $parts');

                          print('LIST OF CONTENT: $currentRow1 + $currentRow2 + $currentRow3');
                        }
                      }, 
                      child: 
                      Card(
                        
                        color: Color.fromARGB(255, 235, 216, 197),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(0),
                        ),
                        child: ListTile(
                          leading: Container(
                            width: 80,
                            height: 80,
                             child: Image.asset(
                              parts[3], 
                              fit: BoxFit.cover, 
                              errorBuilder: (context, error, stackTrace) => const Icon(Icons.error), 
                            ),
                          ),
                          title: Text(parts[0]),
                          subtitle: Text(parts[1]),
                          trailing: Text("⭐ " + parts[2]),
                        ),
                      ));
                    
                    
                })
            ),
            

            SizedBox(height: 20),

            ElevatedButton(
                      style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.brown[300],
                      padding: const EdgeInsets.fromLTRB(35, 25, 35, 25),
                      ),
                    onPressed: () {
                          Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => orderPage()));
                    },
                    child: Text('View Orders'),
                  ),
            
          ],
        ),
      ),
        ),
                        bottomNavigationBar:BottomNavigationBar(
        backgroundColor: Colors.brown[300],
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex, 
        selectedItemColor: Colors.brown, 
        unselectedItemColor: Colors.white,
        onTap: _onItemTapped, 
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
          BottomNavigationBarItem(icon: Icon(Icons.shopping_cart), label: 'Order'),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: 'About'),
        ],
      ),
      );
      

    
     
  }


}

