/*
import 'package:flutter/material.dart';
import 'main.dart';
import 'homePage.dart';
import 'global.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({super.key});

  @override
  State<SignupPage> createState() => _nameState();
}

class _nameState extends State<SignupPage> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController hpController = TextEditingController();
  final TextEditingController pwdController = TextEditingController();
  final TextEditingController con_pwdController = TextEditingController();

  @override
  Widget build(BuildContext context) {
      return  Scaffold(
              backgroundColor: Color.fromARGB(255, 242, 232, 222),

        body:SafeArea(
        child: SingleChildScrollView(
 child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children:[
            Image.asset("logos/logo_text.png"),
            const SizedBox(height:50),
            const Text("Register",style:TextStyle(fontSize:30,fontWeight:FontWeight.w300)),
            const SizedBox(height:20),
            Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              height:50,
              child: TextField(
                controller:nameController,
                decoration: const InputDecoration(
                  labelText: 'Name: ',
                    labelStyle: TextStyle(color: Colors.brown),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Colors.brown,width: 2),
                    ),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Color.fromARGB(255, 232, 164, 139), width: 2),
                    ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              height:50,
              child: TextField(
                controller:emailController,
                decoration: const InputDecoration(
                  labelText: 'Email: ',
                    labelStyle: TextStyle(color: Colors.brown),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Colors.brown,width: 2),
                    ),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Color.fromARGB(255, 232, 164, 139), width: 2),
                    ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              height:50,
              child: TextField(
                controller:hpController,
                decoration: const InputDecoration(
                  labelText: 'Phone No: ',
                    labelStyle: TextStyle(color: Colors.brown),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Colors.brown,width: 2),
                    ),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Color.fromARGB(255, 232, 164, 139), width: 2),
                    ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              height:50,
              child: TextField(
                controller:pwdController,
                decoration: const InputDecoration(
                  labelText: 'Password: ',
                    labelStyle: TextStyle(color: Colors.brown),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Colors.brown,width: 2),
                    ),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Color.fromARGB(255, 232, 164, 139), width: 2),
                    ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              height:50,
              child: TextField(
                controller:con_pwdController,
                decoration: const InputDecoration(
                  labelText: 'Confirm Password: ',
                    labelStyle: TextStyle(color: Colors.brown),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Colors.brown,width: 2),
                    ),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Color.fromARGB(255, 232, 164, 139), width: 2),
                    ),
                ),
              ),
            ),
          ),
                    SizedBox(height:20),

              GestureDetector(
              onTap: () {
                Navigator.pop(context);
              },
              child: const Text(
                'Go to Register Page',
                style: TextStyle(
                  color: Colors.brown,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
                                  SizedBox(height:25),

          ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.brown[300],
                padding: const EdgeInsets.fromLTRB(35, 25, 35, 25),
              ),
              onPressed: () {
                Profile.name = nameController.text;
                Profile.email = emailController.text;
                Profile.hp = hpController.text;
                Profile.password = pwdController.text;
                Profile.confirm_password = con_pwdController.text;
                Navigator.push(context, MaterialPageRoute(builder: (context)=>homePage()));
              },
              child: const Text(
                'Signup',
                style: TextStyle(color: Colors.white, fontSize: 16),
              ),
            ),
          ]
        )
        )
        
        )
     
      );
}
}
*/

import 'package:flutter/material.dart';
import 'homePage.dart';
import 'global.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({super.key});

  @override
  State<SignupPage> createState() => _SignupState();
}

class _SignupState extends State<SignupPage> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController hpController = TextEditingController();
  final TextEditingController pwdController = TextEditingController();
  final TextEditingController conPwdController = TextEditingController();

  String? nameError;
  String? emailError;
  String? phoneError;
  String? passwordError;
  String? confirmPasswordError;

  void _signup() {
    setState(() {
      nameError = _validateUsername(nameController.text);
      emailError = _validateEmail(emailController.text);
      phoneError = _validatePhone(hpController.text);
      passwordError = _validatePassword(pwdController.text);
      confirmPasswordError = _validateConfirmPassword(conPwdController.text);
    });

    if (nameError == null &&
        emailError == null &&
        phoneError == null &&
        passwordError == null &&
        confirmPasswordError == null) {
      Profile.name = nameController.text;
      Profile.email = emailController.text;
      Profile.hp = hpController.text;
      Profile.password = pwdController.text;
      Navigator.push(context, MaterialPageRoute(builder: (context) => homePage()));
    }
  }

  String? _validateUsername(String value) {
    if(value.isEmpty){
      return "Please enter your username";
    } 
    if(value.length < 3){
      return "Username must be at least 3 characters long";
    }
    if(value == Profile.name) {
      return "Username cannot be duplicated";
      }
    return null;
  }

  String? _validateEmail(String value) {
    if(value.isEmpty) 
    {
      return "Please enter your email";
      }
    final emailRegex = RegExp(r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$');
    if (!emailRegex.hasMatch(value)) 
    {
      return "Enter a valid email address";
      }
    return null;
  }

  String? _validatePhone(String value) {
    if (value.isEmpty) {
      return "Please enter your phone number";
      }
    if (!RegExp(r'^\d{8}$').hasMatch(value)) {
      return "Phone number must be exactly 8 digits";
      }
    return null;
  }

  String? _validatePassword(String value) {
    if(value.isEmpty) {
      return "Please enter a password";
      }
    if(value.length < 8) 
    {
      return "Password must be at least 8 characters long";
      }
    if(!RegExp(r'^(?=.*[A-Z])').hasMatch(value)) {
      return "Must contain at least one uppercase letter";
      }
    if(!RegExp(r'^(?=.*[a-z])').hasMatch(value)) {
      return "Must contain at least one lowercase letter";
      }
    if(!RegExp(r'^(?=.*\d)').hasMatch(value)) {
      return "Must contain at least one number";
      }
    if(!RegExp(r'^(?=.*[@$!%*?&])').hasMatch(value)) {
      return "Must contain at least one special character";
      }
    return null;
  }

  String? _validateConfirmPassword(String value) {
    if(value.isEmpty) {
      return "Please confirm your password";
      }
    if(value != pwdController.text) {
      return "Passwords do not match";}
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 242, 232, 222),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.asset("logos/logo_text.png"),
              const SizedBox(height: 30),
              const Text("Register", style: TextStyle(fontSize: 30, fontWeight: FontWeight.w300)),
              const SizedBox(height: 20),

              TextField(
                controller: nameController,
                decoration: InputDecoration(
                  labelText: 'Name:',
                  
                                        labelStyle: const TextStyle(color: Colors.brown),
                      enabledBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.brown, width: 2),
                      ),
                      focusedBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: Color.fromARGB(255, 232, 164, 139), width: 2),
                      ),
                  errorText: nameError,
                ),
              ),
              const SizedBox(height: 15),

              TextField(
                controller: emailController,
                decoration: InputDecoration(
                  labelText: 'Email:',
                                        labelStyle: const TextStyle(color: Colors.brown),
                      enabledBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.brown, width: 2),
                      ),
                      focusedBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: Color.fromARGB(255, 232, 164, 139), width: 2),
                      ),
                  errorText: emailError,
                ),
              ),
              const SizedBox(height: 15),

              TextField(
                controller: hpController,
                decoration: InputDecoration(
                  labelText: 'Phone No:',
                  labelStyle: const TextStyle(color: Colors.brown),
                  errorText: phoneError,
                ),
              ),
              const SizedBox(height: 15),

              TextField(
                controller: pwdController,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'Password:',
                  labelStyle: const TextStyle(color: Colors.brown),
                  errorText: passwordError,
                ),
              ),
              const SizedBox(height: 15),

              TextField(
                controller: conPwdController,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'Confirm Password:',
                  labelStyle: const TextStyle(color: Colors.brown),
                  errorText: confirmPasswordError,
                ),
              ),
              const SizedBox(height: 25),

              GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: const Text(
                  'Go to Login Page',
                  style: TextStyle(color: Colors.brown, decoration: TextDecoration.underline),
                ),
              ),
              const SizedBox(height: 20),

              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.brown[300],
                  padding: const EdgeInsets.symmetric(horizontal: 35, vertical: 20),
                ),
                onPressed: _signup,
                child: const Text('Signup', style: TextStyle(color: Colors.white, fontSize: 16)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
