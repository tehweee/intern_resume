import 'package:image_picker/image_picker.dart';
import 'dart:io';

abstract class Profile{
  static String name = "";
  static String email = "";
  static String hp = "";
  static String password = "";
  static String confirm_password = "";
  static String profilePic = "icons/guest.jpg";
  static File? selectedImage;
}

