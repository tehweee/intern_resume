<?php
/*
    require_once('dbinfo.php');
    require_once('commonFunction.php');
    session_start();
    */
        /*
    $sql="SELECT * FROM users WHERE userID = '".$_POST['userID']."'";
    $results = $mysqli->query($sql);
    if($results->num_rows == 0){
        $sql="SELECT * FROM users WHERE email = '".$_POST['email']."'";
        $results = $mysqli->query($sql);
        if($results->num_rows == 0){

        $sql="INSERT INTO users 
        VALUES
        ('".$_POST['userID']."',
        '".$_POST['email']."',
        '".$_POST['phone']."',
        '".$_POST['name']."',
        '".$_POST['password']."')";
        $mysqli->query($sql);
        $_SESSION['userID'] = $_POST['userID'];
        $_SESSION['name'] = $_POST['name'];
        $_SESSION['email'] = $_POST['email'];
        $_SESSION['phoneNumber'] = $_POST['phone'];
        header("Location: index.php");
        }else{
            header("Location: index.php?error=50001");
        }
    }else{
        header("Location: index.php?error=60001");
    }
        */
?>

<?php
    require_once('commonFunction.php');
    require_once('dbinfo.php');
    session_start();

    $sql="SELECT * FROM users WHERE userID = ?";
    $queryStatement = mysqli_prepare($connection,$sql);
    $_POST['userID'] = sanitized($_POST['userID']);
    mysqli_stmt_bind_param($queryStatement,'s',$_POST['userID']);
    mysqli_stmt_execute($queryStatement);
    mysqli_stmt_store_result($queryStatement);
    $count = mysqli_stmt_num_rows($queryStatement);
    mysqli_stmt_bind_result($queryStatement,$uID,$e,$hp,$n,$p,$pfp,$cp,$f);
    mysqli_stmt_fetch($queryStatement);

    if($count == 0){
        $sql="SELECT * FROM users WHERE email = ?";
        $queryStatement = mysqli_prepare($connection,$sql);
        $_POST['email'] = sanitized($_POST['email']);
        mysqli_stmt_bind_param($queryStatement,'s',$_POST['email']);
        mysqli_stmt_execute($queryStatement);
        mysqli_stmt_store_result($queryStatement);
        $count = mysqli_stmt_num_rows($queryStatement);
        mysqli_stmt_bind_result($queryStatement,$uID,$e,$hp,$n,$p,$pfp,$cp,$f);
        mysqli_stmt_fetch($queryStatement);

        if($count == 0){
        $hashPW = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $hashCPW = password_hash($_POST['c_password'], PASSWORD_DEFAULT);



        $sql="INSERT INTO users (`userID`,`email`,`phoneNumber`,`name`,`password`,`confirm_password`,`favorite`)VALUES (?,?,?,?,?,?,?)";
        $queryStatement = mysqli_prepare($connection,$sql);
        $_POST['userID'] = sanitized($_POST['userID']);
        $_POST['email'] = sanitized($_POST['email']);
        $_POST['phone'] = sanitized($_POST['phone']);
        $_POST['name'] = sanitized($_POST['name']);
        $hashPW = sanitized($hashPW);
        $hashCPW = sanitized($hashCPW);
        $_POST['favor'] = sanitized($_POST['favor']);
        mysqli_stmt_bind_param($queryStatement,'sssssss',
        $_POST['userID'],
        $_POST['email'],
        $_POST['phone'],
        $_POST['name'],
        $hashPW,
        $hashCPW,
        $_POST['favor']);

        mysqli_stmt_execute($queryStatement);
        $_SESSION['userID'] = $_POST['userID'];
        $_SESSION['name'] = $_POST['name'];
        $_SESSION['email'] = $_POST['email'];
        $_SESSION['phoneNumber'] = $_POST['phone'];
        header("Location: index.php");
        }else{
            header("Location: index.php?error=50001");
        }
    }else{
        header("Location: index.php?error=60001");
    }
    
?>
