<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel=stylesheet href="css/css_reset.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400..900&display=swap" rel="stylesheet">
    <link rel=stylesheet href="css/about.css">
    <link rel=stylesheet href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/common.css">
</head>
<body>
    <?php 
    include("header.php");
    require_once('dbinfo.php');
    $sql = "SELECT * FROM aboutpageinfo";
    $results = $mysqli->query($sql);
    $result = $results->fetch_assoc();
    ?>

    <main>
        <section id="missionContainer">
            <h1 id="missionTitle">Chi siamo</h1>
            <div id="missionInfo">
                <img id="missionImage" src="img/<?php echo $result['titleImg']?>" alt="title_img">
                <section id="missionDescContainer">
                    <h2 id="missionQuote">"<?php echo $result['startQuote']?>"</h2>
                    <p id="missionDescription"><?php echo $result['description']?></p>
                </section>
            </div>
        </section>
        <hr>
        <section id="teamContainer">
            <h1 id="teamTitle">Meet the Team</h1>
            <?php 
            $sqlChef = "SELECT * FROM chefinfo";
            $chefresults = $mysqli->query($sqlChef);
            ?>
            <div id = "imageGrid">
                <?php             
                while($chefresult = $chefresults->fetch_assoc()){
                    ?>
                <section class="chefCard">
                    <img class="chefImage" src="img/<?php echo $chefresult['chefImg']?>" alt="chef_image">
                    <h2 class="chefName"><?php echo $chefresult['chefName']?></h2>
                    <p class="chefRole"><?php echo $chefresult['chefRole']?></p>
                </section>
                <?php }?>
            </div>
            <p id="endQuote">"<?php echo $result['endQuote']?>"</p>
        </section>
    </main>

    <?php include("footer.php")?>
</body>
</html>