<?php
    require_once("dbinfo.php");
    require_once('commonFunction.php');
    session_start();
    /*
    $sql = "DELETE FROM users WHERE userID = '".$_SESSION['userID']."'";
    $mysqli->query($sql);
    $sql = "DELETE FROM contact WHERE email = '".$_SESSION['email']."'";
    $mysqli->query($sql);
    $sql = "DELETE FROM reservations WHERE userIDFK = '".$_SESSION['userID']."'";
    $mysqli->query($sql);
    */
    $sql = "DELETE FROM users WHERE userID = ?";
    $queryStatement = mysqli_prepare($connection,$sql);
    $_SESSION['userID'] = sanitized($_SESSION['userID']);
    mysqli_stmt_bind_param($queryStatement,'s',$_SESSION['userID']);
    mysqli_stmt_execute($queryStatement);

    $sql = "DELETE FROM contact WHERE email = ?";
    $queryStatement = mysqli_prepare($connection,$sql);
    $_SESSION['email'] = sanitized($_SESSION['email']);
    mysqli_stmt_bind_param($queryStatement,'s',$_SESSION['email']);
    mysqli_stmt_execute($queryStatement);


    $sql = "DELETE FROM reservations WHERE userIDFK = ?";
    $queryStatement = mysqli_prepare($connection,$sql);
    $_SESSION['userID'] = sanitized($_SESSION['userID']);
    mysqli_stmt_bind_param($queryStatement,'s',$_SESSION['userID']);
    mysqli_stmt_execute($queryStatement);
    
    session_unset();
    session_destroy();
    header("Location: index.php");
?>