<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel=stylesheet href="css/css_reset.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400..900&display=swap" rel="stylesheet">
    <link rel=stylesheet href="css/outlet.css">
    <link rel=stylesheet href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/common.css">
</head>
<body>
    <?php include("header.php");
    require_once("commonFunction.php");?>

    <main id="outletSection">
        <form action="outlet.php" method="post" id="searchPanel">
            <h1 id="panelTitle">Search Panel</h1>
            <div id="panelSelection">
                <div>
                    <input type="text" class="name" name="location" placeholder="Location">
                </div>
                <div class="radio">
                    <label>Availability: </label>
                    <label for="yes">Yes </label>
                    <input type="radio" name="avail" value="1">
                    <label for="no">No </label>
                    <input type="radio" name="avail" value="0">
                    <input type="radio" name="avail" value="" checked style="display:none">
                    </div>
                <div>
                <select id="dine" name="dine">
                <option value="" selected>Dining Time</option>
                    <option value="12:00-2:00">Lunch (12:00-2:00)</option>
                    <option value="6:00-8:00">Dinner (6:00-8:00)</option>
                </select>
                </div>
                <div>
                    <input type="text" id="noGuest" name="noGuest" placeholder="Number Of Guest">
                </div>
                <div class="radio">
                    <label>VIP Room: </label>
                    <label for="yes">Yes </label>
                    <input type="radio" id="yes" name="viproom" value="1">
                    <label for="no">No </label>
                    <input type="radio" id="no" name="viproom" value="0">
                    <input type="radio" name="viproom" value="" checked style="display:none">
                </div>
            </div>
            <div id="panelSubmit">
                <button class=button>Filter Now</button>
            </div>
        </form>
        <?php   
            require_once('dbinfo.php');
            if(isset($_POST['location'])){
                if(strlen($_POST['noGuest']) == 0){
                    $_POST['noGuest'] = 0;
                }
                /*
                $sql = "SELECT * FROM outlets WHERE 
                location LIKE '%".$_POST['location']."%' 
                && 
                availability LIKE '%".$_POST['avail']."%' 
                && 
                maxGuest >= ".$_POST['noGuest']."
                &&
                VIPRoom LIKE '%".$_POST['viproom']."%';";
                */
                $location_field = '%'.$_POST['location'].'%';
                $availability_field = '%'.$_POST['avail'].'%';
                $maxGuest_field = $_POST['noGuest'];
                $viproom_field = '%'.$_POST['viproom'].'%';

                $sql = "SELECT * FROM outlets WHERE location LIKE ? && availability LIKE ? && maxGuest >= ? && VIPRoom LIKE ?";
                $queryStatement = mysqli_prepare($connection,$sql);
                $location_field = sanitized($location_field);
                $availability_field = sanitized($availability_field);
                $maxGuest_field = sanitized($maxGuest_field);
                $viproom_field = sanitized($viproom_field);
                mysqli_stmt_bind_param($queryStatement,'ssis',$location_field,$availability_field,$maxGuest_field,$viproom_field);
            }
            else{
                
                $sql = "SELECT * FROM outlets";
                $queryStatement = mysqli_prepare($connection,$sql);

            }

            /*
            $results = $mysqli->query($sql);
            */
            mysqli_stmt_execute($queryStatement);
            mysqli_stmt_store_result($queryStatement);
            $count = mysqli_stmt_num_rows($queryStatement);
            mysqli_stmt_bind_result($queryStatement,$outletID,$location,$availability,$maxGuest,$VIPRoom,$outletImg);

        ?>
        <div id="outletDisplay">
            <?php 
            while(mysqli_stmt_fetch($queryStatement)){
            ?>
            <div class="indiOutlet">
                <img class="outletImage" src="img/<?php echo $outletImg;?>" alt="outlet_image">
                <div class="outletDetail">
                    <div class="locationTitle"><?php echo $location;?></div>
                    <div class="outletFeatures">
                        <div class="left_col">
                            <div class="seat">Restaurant Status: <?php if($availability){echo "Available";}else{echo "Unavailable";}?></div>
                            <div class="vip">VIP Room Status: <?php if($VIPRoom){echo "Available";}else{echo "Unavailable";}?></div>
                        </div>
                        <div class="right_col">
                            <div class="dining">Dining Timing: <?php 
                            /*
                                $timeSQL = "SELECT diningTime FROM diningtime WHERE outletID = '".$outletID."'";
                                $timeresults = $mysqli->query($timeSQL);
                                while($timeresult = $timeresults->fetch_assoc()){
                                    echo $timeresult['diningTime'].",";
                                }
                                    */
                                $timeSQL = "SELECT diningTime FROM diningtime WHERE outletID = ?";
                                $queryStatement6 = mysqli_prepare($connection,$timeSQL);
                                $outletID = sanitized($outletID);
                                mysqli_stmt_bind_param($queryStatement6,'s',$outletID);
                                mysqli_stmt_execute($queryStatement6);

                                mysqli_stmt_store_result($queryStatement6);
                                $count = mysqli_stmt_num_rows($queryStatement6);
                                mysqli_stmt_bind_result($queryStatement6,$diningTime);

                                while(mysqli_stmt_fetch($queryStatement6)){
                                    echo $diningTime.",";
                                }

                            ?></div>
                            <div class="maxGuest">Max no of Guest: <?php echo $maxGuest;?></div>
                        </div>
                    </div>
                    <div class="reservationBTN"><a class="button" <?php if($availability){ echo "href=reservation_page.php?outletid=".sanitized($outletID)."";}else{ echo "style='color:lightgray'";}?>>Make Reservation</a></div>
                </div>
            </div>
            <?php }?>
        </div>
    </main>
    <?php include("footer.php")?>
</body>
</html>