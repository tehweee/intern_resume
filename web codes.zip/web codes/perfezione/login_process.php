<?php
    require_once("dbinfo.php");
    require_once('commonFunction.php');

    session_start();
    
    $sql = "SELECT * FROM users WHERE userID = ?";
    $queryStatement = mysqli_prepare($connection,$sql);
    $_POST['userID'] = sanitized($_POST['userID']);
    mysqli_stmt_bind_param($queryStatement,'s',$_POST['userID']);
    mysqli_stmt_execute($queryStatement);
    mysqli_stmt_store_result($queryStatement);
    $count = mysqli_stmt_num_rows($queryStatement);
    mysqli_stmt_bind_result($queryStatement,$uID,$e,$hp,$n,$p,$pfp,$cp,$f);
    mysqli_stmt_fetch($queryStatement);
    if($count == 1){
        if(password_verify($_POST['password'],$p)){
            $_SESSION['userID'] = $uID;
            $_SESSION['name'] = $n;
            $_SESSION['email'] = $e;

            $_SESSION['phoneNumber'] = $hp;
            header('Location: welcome.php');
        }else{
            header('Location: index.php?error=20001');
        }
    }else{
        header('Location: index.php?error=10001');
    }
        
        /*
        $sql = "SELECT * FROM users WHERE userID = '".$_POST['userID']."'";
        $results = $mysqli->query($sql);
        if($results->num_rows == 1){
            if($_POST['password'] == $results['password']){
                $_SESSION['userID'] = $results['userID'];
                $_SESSION['name'] = $results['name'];
                $_SESSION['email'] = $results['email'];
    
                $_SESSION['phoneNumber'] = $results['phoneNumber'];
                header('Location: welcome.php');
            }else{
                header('Location: index.php?error=20001');
            }
        }else{
            header('Location: index.php?error=10001');
        }
            */
?>