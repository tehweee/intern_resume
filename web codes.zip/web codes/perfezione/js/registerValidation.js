let registerFormValid = document.getElementById('registerFormValid');
let formUserID = document.getElementById('userID');
let formName = document.getElementById('name');
let formEmail = document.getElementById('email');
let formPhone = document.getElementById('phone');
let formPassword = document.getElementById('password');
let form_cPassword = document.getElementById('c_password');

let userIDError = document.getElementById('userIDError');
let nameError = document.getElementById('nameError');
let emailError = document.getElementById('emailError');
let phoneError = document.getElementById('phoneError');
let passError = document.getElementById('passError');
function validateUserID(str){
    let pattern = /^[A-Za-z0-9]+$/;
    return pattern.test(str);
}
function validateName(str) {
    let pattern = /^[a-zA-Z\s]+$/;
    return pattern.test(str);
}


function validateMobile(str) {
    return /^\d{8}$/.test(str);
}


function validateEmail(str){
    return /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(str);
}

function validateForm(){
    if((validateUserID(formUserID.value))){
        if((formName.value.length <= 16 && formName.value.length > 2)&& validateName(formName.value)){
            if(validateEmail(formEmail.value)){
                if(validateMobile(formPhone.value) && formPhone.value.length == 8){
                    if((formPassword.value.length <= 40 && formPassword.value.length >= 8) && (formPassword.value == form_cPassword.value)){
                        return true;
                    }else{
                        passError.innerHTML="Password has to be within 8-40 characters!";
                        return false;
                    }
                }else{
                    phoneError.innerHTML="Invalid phone number being prompted, try again!";
                    return false;
                }
            }else{
                emailError.innerHTML = "Invalid email being prompted, try again!";
                return false;
            }
        }else{
            nameError.innerHTML = "Invalid name being prompted, try again!";
            return false;
        }
    }else{
        userIDError.innerHTML = "Invalid userID being prompted, try again!";
        return false;
    }
}
registerFormValid.addEventListener("submit",function(event) {
    event.preventDefault();
    userIDError.innerHTML = "";
    nameError.innerHTML = "";
    emailError.innerHTML = "";
    phoneError.innerHTML = "";
    passError.innerHTML = "";
    if(validateForm()){
        this.submit();
    }
});