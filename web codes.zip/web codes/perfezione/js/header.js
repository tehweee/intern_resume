hbPop = document.getElementById('hbPopUp');
hb = document.getElementById('hbContainer');

login = document.getElementById('loginAnchor');

accPanel = document.querySelector('.accPanel');
registerPanel = document.querySelector('.registerPanel');

form = document.querySelectorAll('.accForm');
container = document.querySelectorAll('.accCont');
lbl = document.querySelectorAll('.accLBL');
title = document.querySelectorAll('.accTitle');
input = document.querySelectorAll('.accInt');
btn = document.querySelectorAll('.accButton');

openRegister = document.querySelector('.openRegister');
openLogin = document.querySelector('.openLogin');
accountAnchor = document.querySelectorAll('.accountAnchor');

outletAnc = document.querySelectorAll('.outletAnchor');
reservationAnc = document.querySelectorAll('.reservationAnchor');

backgroundTint = document.getElementById('backgroundTint');

btnCont = document.querySelectorAll('.btnCont');
exitButton = document.querySelectorAll('.exitButton');

hbPop.style.display = "none";

accPanel.style.display = "none";
registerPanel.style.display = "none";



toggle = false;

function hb_active(){
    if(toggle == false){
        hbPop.style.position = "absolute";
        hbPop.style.backgroundColor="#bd9d7d";
        hbPop.style.top="100px";
        hbPop.style.right="0";
        hbPop.style.left="0";
        hbPop.style.height="600px";
        hbPop.style.display="flex";
        hbPop.style.flexDirection= "column";
        hbPop.style.justifyContent= "space-evenly";
        hbPop.style.alignItems= "center";
        toggle = true;
    }else if(toggle == true){
        hbPop.style.display = "none";
        toggle = false;
    }
}
function lp(){
    for(let i = 0; i < title.length;i++){
    title[i].style.fontSize = "50px";
    }
    for(let i = 0; i < lbl.length;i++){
        lbl[i].style.fontSize="13px";
    }
    for(let i = 0; i < input.length;i++){
        input[i].style.border="none";
        input[i].style.borderBottom="1px solid black";
        input[i].style.width="100%";
        input[i].style.fontSize="20px";
        input[i].style.fontDamily= '"Montserrat", sans-serif';
        input[i].style.fontOpticalSizing= "auto";
        input[i].style.fontStyle= "normal";
    }
    for(let i = 0; i < container.length;i++){
        container[i].style.display="flex";
        container[i].style.flexDirection="column";
        container[i].style.width="100%";
    }
    for(let i = 0; i < btn.length;i++){
        btn[i].style.padding="20px 25px";
        btn[i].style.fontFamily= '"Montserrat", sans-serif';
        btn[i].style.fontOpticalSizing= "auto";
    }
    for(let i = 0;i < exitButton.length;i++){
        exitButton[i].style.width = "50px";
        exitButton[i].style.height = "50px";
        exitButton[i].style.border = "none";
        exitButton[i].style.borderRadius = "50%";
        exitButton[i].style.position = "absolute";
        exitButton[i].style.top = "-12px";
        exitButton[i].style.right = "-12px";
        exitButton[i].style.backgroundColor = "rgba(240, 240, 240, 0.8)";
    }
    for(let i = 0;i < form.length;i++){
        form[i].style.display= "flex";
        form[i].style.flexDirection="column";
        form[i].style.alignItems= "center";
        form[i].style.fontFamily= '"Montserrat", sans-serif';
        form[i].style.fontOpticalSizing = "auto";
        form[i].style.fontStyle= "normal";
        form[i].style.width="70%";
        form[i].style.gridGap="60px";
    }
    for(let i = 0; i <btnCont.length;i++){
        btnCont[i].style.display="flex";
        btnCont[i].style.flexDirection="row";
        btnCont[i].style.gridGap="10px";
    }
    backgroundTint.style.display = "block";
    backgroundTint.style.backgroundColor = "black";
        backgroundTint.style.backgroundColor = "black";

}
function winResizeCheck(){
        accPanel.style.display = "none";
        registerPanel.style.display = "none";
        hbPop.style.display="none";
        backgroundTint.style.display = "none";

}

window.addEventListener("resize",winResizeCheck);

function showLogin(){
    accPanel.style.display = "flex";
    accPanel.style.position="fixed";
    if(window.innerWidth <= 480){
        accPanel.style.width="400px";
    }else{
        accPanel.style.width="600px";
    }
    accPanel.style.height="500px";
    accPanel.style.top= "450px";
    accPanel.style.bottom="450px";
    accPanel.style.left= "50%";
    accPanel.style.transform= "translate(-50%, -50%)";
    accPanel.style.backgroundColor="white";
    accPanel.style.borderRadius="10%";
    accPanel.style.flexDirection="column";
    accPanel.style.justifyContent= "center";
    accPanel.style.alignItems= "center";
    accPanel.style.zIndex= "9999";
    registerPanel.style.display = "none";
    lp();
}
function showRegister(){
    registerPanel.style.display = "flex";
    registerPanel.style.position="fixed";
    if(window.innerWidth <= 480){
        registerPanel.style.width="400px";
    }else{
        registerPanel.style.width="600px";
    }
    registerPanel.style.height="700px";
    registerPanel.style.top= "450px";
    registerPanel.style.bottom="450px";
    registerPanel.style.left= "50%";
    registerPanel.style.transform= "translate(-50%, -50%)";
    registerPanel.style.backgroundColor="white";
    registerPanel.style.borderRadius="10%";
    registerPanel.style.flexDirection="column";
    registerPanel.style.justifyContent= "center";
    registerPanel.style.alignItems= "center";
    registerPanel.style.zIndex= "9999";
    accPanel.style.display = "none";
    lp();
    for(let i = 0;i < form.length;i++){
        form[i].style.gridGap="10px";
    }
}

hb.addEventListener('click',hb_active);
login.addEventListener('click',showLogin);

exitButton[0].addEventListener('click',()=>{
    accPanel.style.display = "none";
    registerPanel.style.display = "none";
    backgroundTint.style.display = "none";
});

exitButton[1].addEventListener('click',()=>{
    accPanel.style.display = "none";
    registerPanel.style.display = "none";
    backgroundTint.style.display = "none";
});

openRegister.addEventListener('click',()=>{
    showRegister()
    console.log('open register');
}
);

openLogin.addEventListener('click',()=>{
    showLogin();
    console.log('open log');
});
reservationAnc[0].addEventListener('click',()=>{
    hbPop.style.display = "none";
    showLogin();
    console.log('open log');
});
reservationAnc[1].addEventListener('click',()=>{
    hbPop.style.display = "none";
    showLogin();
    console.log('open log');
});
accountAnchor[0].addEventListener('click',()=>{
    hbPop.style.display="none";
    showLogin();
    console.log('open log');
});
accountAnchor[1].addEventListener('click',()=>{
    hbPop.style.display="none";
    showLogin();
    console.log('open log');
});
outletAnc[0].addEventListener('click',()=>{
    hbPop.style.display="none";
    showLogin();
    console.log('open log');
});
outletAnc[1].addEventListener('click',()=>{
    hbPop.style.display="none";
    showLogin();
    console.log('open log');
});



