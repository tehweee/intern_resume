changeName = document.getElementById("changeName");
nameDisplay = document.getElementById("nameDisplay");
namePrompt = document.getElementById("namePrompt");
nameUpdate = document.getElementById("nameUpdate");
nameErr = document.getElementById("nameErr");

changeEmail = document.getElementById("changeEmail");
emailDisplay = document.getElementById("emailDisplay");
emailPrompt = document.getElementById("emailPrompt");
emailUpdate = document.getElementById("emailUpdate");
emailErr = document.getElementById("emailErr");

changePhone = document.getElementById("changePhone");
phoneDisplay = document.getElementById("phoneDisplay");
phonePrompt = document.getElementById("phonePrompt");
phoneUpdate = document.getElementById("phoneUpdate");
phoneErr = document.getElementById("phoneErr");

changPass = document.getElementById("changePass");
passDisplay = document.getElementById("passDisplay");
passPrompt = document.getElementById("passPrompt");
passUpdate = document.getElementById("passUpdate");
passErr = document.getElementById("passErr");

changUserID = document.getElementById("changeUserID");
UserIDDisplay = document.getElementById("userIDDisplay");
UserIDPrompt = document.getElementById("userIDPrompt");
UserIDUpdate = document.getElementById("userIDUpdate");
UserIDErr = document.getElementById("userIDErr");

userIDToggle = true;
nameToggle = true;
emailToggle = true;
phoneToggle = true;
passToggle = true;

function reset(){
    namePrompt.style.display = "none";
    nameDisplay.style.display = "inline-block";

    emailPrompt.style.display = "none";
    emailDisplay.style.display = "inline-block";

    phonePrompt.style.display = "none";
    phoneDisplay.style.display = "inline-block";

    passPrompt.style.display = "none";
    passDisplay.style.display = "inline-block";

    UserIDPrompt.style.display = "none";
    UserIDDisplay.style.display = "inline-block";
}
function clear_err(){
    nameErr.innerHTML = "";
    emailErr.innerHTML = "";
    passErr.innerHTML = "";
    phoneErr.innerHTML = "";
    UserIDErr.innerHTML = "";

    nameUpdate.value = "";
    emailUpdate.value = "";
    passUpdate.value = "";
    phoneUpdate.value = "";
    UserIDUpdate.value = "";

}
changUserID.addEventListener('click',()=>{
    clear_err();
    if(userIDToggle){
        namePrompt.style.display = "none";
        nameDisplay.style.display = "inline-block";

        emailPrompt.style.display = "none";
        emailDisplay.style.display = "inline-block";

        phonePrompt.style.display = "none";
        phoneDisplay.style.display = "inline-block";

        passPrompt.style.display = "none";
        passDisplay.style.display = "inline-block";

        UserIDPrompt.style.display = "inline-block";
        UserIDDisplay.style.display = "none";
        userIDToggle = false;
    }else{
        reset();
        userIDToggle = true;
    }
});

changeName.addEventListener('click',()=>{
    clear_err();
    if(nameToggle){
        namePrompt.style.display = "inline-block";
        nameDisplay.style.display = "none";

        emailPrompt.style.display = "none";
        emailDisplay.style.display = "inline-block";

        phonePrompt.style.display = "none";
        phoneDisplay.style.display = "inline-block";

        passPrompt.style.display = "none";
        passDisplay.style.display = "inline-block";

        UserIDPrompt.style.display = "none";
        UserIDDisplay.style.display = "inline-block";
        nameToggle = false;
    }else{
        reset();
        nameToggle = true;
    }
});


changeEmail.addEventListener('click',()=>{
    clear_err();
    if(emailToggle){
        emailPrompt.style.display = "inline-block";
        emailDisplay.style.display = "none";

        namePrompt.style.display = "none";
        nameDisplay.style.display = "inline-block";

        phonePrompt.style.display = "none";
        phoneDisplay.style.display = "inline-block";

        passPrompt.style.display = "none";
        passDisplay.style.display = "inline-block";

        UserIDPrompt.style.display = "none";
        UserIDDisplay.style.display = "inline-block";

        emailToggle = false;
    }else{
        reset();
        emailToggle = true;
    }
});

changePhone.addEventListener('click',()=>{
    clear_err();
    if(phoneToggle){
        phonePrompt.style.display = "inline-block";
        phoneDisplay.style.display = "none";

        namePrompt.style.display = "none";
        nameDisplay.style.display = "inline-block";

        passPrompt.style.display = "none";
        passDisplay.style.display = "inline-block";

        emailPrompt.style.display = "none";
        emailDisplay.style.display = "inline-block";

        UserIDPrompt.style.display = "none";
        UserIDDisplay.style.display = "inline-block";
        phoneToggle = false;
    }else{
        reset();
        phoneToggle = true;
    }
});

changePass.addEventListener('click',()=>{
    clear_err();
    if(passToggle){
        passPrompt.style.display = "inline-block";
        passDisplay.style.display = "none";

        phonePrompt.style.display = "none";
        phoneDisplay.style.display = "inline-block";

        namePrompt.style.display = "none";
        nameDisplay.style.display = "inline-block";

        emailPrompt.style.display = "none";
        emailDisplay.style.display = "inline-block";

        UserIDPrompt.style.display = "none";
        UserIDDisplay.style.display = "inline-block";
        passToggle = false;
    }else{
        reset();
        passToggle = true;
    }
});
function validateUserID(str){
    let pattern = /^[A-Za-z0-9]+$/;
    return pattern.test(str);
}
function validateName(str) {
    let pattern = /^[a-zA-Z\s]+$/;
    return pattern.test(str);
}
function validateEmail(str){
    return /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(str);
}
function validateMobile(str) {
    return /^\d{8}$/.test(str);
}
UserIDPrompt.addEventListener("submit",function(event){
    event.preventDefault();
    if(validateUserID(UserIDUpdate.value)){
        this.submit();
    }else{
        UserIDErr.innerHTML = "Invalid UserID being prompted, try again!";
    }
});
namePrompt.addEventListener("submit",function(event){
    event.preventDefault();
    if((nameUpdate.value.length <= 16 && nameUpdate.value.length > 2)&& validateName(nameUpdate.value)){
        this.submit();
    }else{
        nameErr.innerHTML = "Invalid name being prompted, try again!";
    }
});

emailPrompt.addEventListener("submit",function(event){
    event.preventDefault();
    if(validateEmail(emailUpdate.value)){
        this.submit();
    }else{
        emailErr.innerHTML = "Invalid email being prompted, try again!";
    }
});

phonePrompt.addEventListener("submit",function(event){
    event.preventDefault();
    if(validateMobile(phoneUpdate.value) && phoneUpdate.value.length == 8){
        this.submit(); 
    }else{
        phoneErr.innerHTML = "Invalid phone number being prompted, try again!";
    }
});

passPrompt.addEventListener("submit",function(event){
    event.preventDefault();
    if((passUpdate.value.length <= 16 && passUpdate.value.length > 5)){
        this.submit(); 
    }else{
        passErr.innerHTML = "Invalid password being prompted, try again!";
    }
});


