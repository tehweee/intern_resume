let contactName = document.getElementById('contactName');
let contactPhone = document.getElementById('contactPhone');
let contactEmail = document.getElementById('contactEmail');
let feedback = document.getElementById('feedback');


let nameErrorContact = document.getElementById('nameErrorContact');
let emailErrorContact = document.getElementById('emailErrorContact');
let phoneErrorContact = document.getElementById('phoneErrorContact');
let feedbackErrorContact = document.getElementById('feedbackErrorContact');


function validateName(str) {
    let pattern = /^[a-zA-Z\s]+$/;
    return pattern.test(str);
}
function validateMobile(str) {
    return /^\d{8}$/.test(str);
}
function validateEmail(str){
    return /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(str);
}
function validateForm(){
    if(contactName.value.length <= 16 && validateName(contactName.value)){
        console.log(contactEmail.value);
        if(validateEmail(contactEmail.value)){
            if(validateMobile(contactPhone.value) && contactPhone.value.length == 8){
                if(feedback.value.length > 0){
                    return true;
                }else{
                    feedbackErrorContact.innerHTML = "You did not put anything inside the feedback form, try again!";
                    return false;
                }
            }else{
                phoneErrorContact.innerHTML="Invalid phone number being prompted, try again!";
                return false;
            }
        }else{
            emailErrorContact.innerHTML = "Invalid email being prompted, try again!";
            return false;
        }
    }else{
        nameErrorContact.innerHTML = "Invalid name being prompted, try again!";
        return false;
    }
}
document.getElementById('contactFormValid').addEventListener('submit',function(event) {
    event.preventDefault();
    nameErrorContact.innerHTML = "";
    emailErrorContact.innerHTML = "";
    phoneErrorContact.innerHTML = "";
    feedbackErrorContact.innerHTML = "";
    if(passValidation){
        if(validateForm()){
            this.submit();
        }
    }else{
        if(validateForm()){
            this.submit();
        }
    }
});