<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel=stylesheet href="css/css_reset.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400..900&display=swap" rel="stylesheet">
    <link rel=stylesheet href="css/contactForm.css">
    <link rel=stylesheet href="css/footer.css">
    <link rel="stylesheet" href="css/common.css">
</head>
<body>
    <?php include("header.php")?>
    <?php 
    session_start();
    ?>
    <main id="contactForm">
        <h1>Contact Page</h1>
        <form action="contact_process.php" method=post id="contactFormValid">
            <div class="container">
                <label>Name : </label>
                <input type=text value="<?php if(isset($_SESSION['name'])){echo $_SESSION['name'];}?>" id="contactName" name='contactName'>
                <label class="errMsg" id=nameErrorContact></label>
            </div>
            <div class="container">
                <label>Email : </label>
                <input type=text value="<?php if(isset($_SESSION['email'])){echo $_SESSION['email'];}?>" id="contactEmail" name='contactEmail'>
                <label class="errMsg" id=emailErrorContact></label>
            </div>            
            <div class="container">
                <label>Phone Number : </label>
                <input type=text value="<?php if(isset($_SESSION['phoneNumber'])){echo $_SESSION['phoneNumber'];}?>" id="contactPhone" name='contactPhone'>
                <label class="errMsg" id=phoneErrorContact></label>
            </div>
            <div class="container">
                <label>Feedback : </label>
                <textarea id="feedback" name=feedback></textarea>
                <label class="errMsg" id="feedbackErrorContact"></label>
            </div>
            <input type=submit class="button">
        </form>
    </main>
    <?php include("footer.php")?>
    <script>
        <?php
            if(isset($_SESSION['email'])){
                echo "passValidation = true;";
            }else{
                echo "passValidation = false;";
            }
        ?>
    </script>
    <script src="js/contact.js"></script>
</body>
</html>