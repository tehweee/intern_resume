<?php
    require_once('dbinfo.php');
    require_once('commonFunction.php');
    /*
    $sql = "INSERT INTO contact 
    VALUES 
    ('".$_POST['contactEmail']."',
    '".$_POST['contactName']."',
    '".$_POST['contactPhone']."',
    '".$_POST['feedback']."')";

    $mysqli->query($sql);
    */
    
    $sql = "INSERT INTO contact VALUES (?,?,?,?)";
    $queryStatement = mysqli_prepare($connection,$sql);
    $_POST['contactEmail'] = sanitized($_POST['contactEmail']);
    $_POST['contactName'] = sanitized($_POST['contactName']);
    $_POST['contactPhone'] = sanitized($_POST['contactPhone']);
    $_POST['feedback'] = sanitized($_POST['feedback']);
    mysqli_stmt_bind_param($queryStatement,'ssss',$_POST['contactEmail'],
    $_POST['contactName'],
    $_POST['contactPhone'],
    $_POST['feedback']);
    mysqli_stmt_execute($queryStatement);
    
    header("Location: contactForm_confirm.php");
?>