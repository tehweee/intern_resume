<?php
function sanitized($data){
    $data = trim($data);
    
    $data = stripslashes($data);
    
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    
    $patterns = [
        "/(\b(SELECT|INSERT|DELETE|UPDATE|DROP|UNION|EXEC|OR|AND)\b)/i",
        "/(--|#|\*|;|\/\*|\*\/)/", 
        "/(\b(0x|UNHEX|HEX)\b)/i", 
    ];
    $data = preg_replace($patterns, "", $data);
    
    return $data;
}


?>