<?php
$hostname = "localhost";
$dbUser = "root";
$dbPassword = "";
$db = "perferzione";

$mysqli = new mysqli($hostname, $dbUser, $dbPassword, $db);
if ($mysqli->connect_errno)
{
    echo "Failed to connect to MYSQL: ".$mysqli->connect_error;
    exit();
}
$connection = mysqli_connect('localhost', 'root', '');
if (!$connection){
    die("Database Connection Failed" . mysqli_error($connection));
}
$select_db = mysqli_select_db($connection, 'perferzione');
if (!$select_db){
    die("Database Selection Failed" . mysqli_error($connection));
}
?>