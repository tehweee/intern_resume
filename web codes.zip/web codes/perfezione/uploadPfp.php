<?php
    session_start();
    require_once("dbinfo.php");
    require_once('commonFunction.php');
    $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];
    $allowedMimeTypes = ['image/jpeg', 'image/png', 'image/gif'];
    $fileExtension = strtolower(pathinfo(basename($_FILES["user_profile"]["name"]), PATHINFO_EXTENSION));
    if (!in_array($fileExtension, $allowedExtensions) || !in_array(mime_content_type($_FILES["user_profile"]["tmp_name"]), $allowedMimeTypes)) {
        header("Location: unsuccessful_profile_change.php");

    }else{
        $target_dir = "profilePic/";
        $target_file = $target_dir . basename($_FILES["user_profile"]["name"]);
        $newprofilePic = basename( $_FILES["user_profile"]["name"]);
        if (move_uploaded_file($_FILES["user_profile"]["tmp_name"], $target_file))
        {
            header("Location: successful_profile_change.php");
        } else {
        echo "Sorry, there was an error uploading your file.<a href='edit_account.php'>Go back to Edit</a>";
        }
    }

    
    $sql = "UPDATE `users` SET profilePic = ? WHERE userID = ?";
    $queryStatement = mysqli_prepare($connection,$sql);
    $newprofilePic = sanitized($newprofilePic);
    $_SESSION['userID'] = sanitized($_SESSION['userID']);
    mysqli_stmt_bind_param($queryStatement,'ss',$newprofilePic,$_SESSION['userID']);
    mysqli_stmt_execute($queryStatement);




?>