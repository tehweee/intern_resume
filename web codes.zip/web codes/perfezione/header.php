<?php
    require_once('dbinfo.php');
    session_start();
    $login = false;
    if(isset($_SESSION['name'])){
        $login = true;
    }

?>
<link rel=stylesheet href="css/css_reset.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400..900&display=swap" rel="stylesheet">
<link rel=stylesheet href="css/header.css">

<header id="headerNav">
    <ul id="left">
        <li>        
            <a href="index.php">Home</a>
        </li>
        <li>        
            <a href="food.php">Explore Food</a>
        </li>
        <li>        
            <a <?php if(isset($_SESSION['email'])){ echo "href='outlet.php'";}?> class="<?php if(!(isset($_SESSION['email']))){ echo "outletAnchor";}?>">Outlets</a>
        </li>
        <li>        
            <a href="about.php">About</a>
        </li>
        <li>        
            <a href="contact.php">Contact</a>
        </li>
    </ul>
    <ul id="logo">  
        <li>
            <a href="index.php"><img src="img/logo_head.png" alt="logo"> </a>
        </li>
    </ul>
    <ul id="right">
        <li>        
            <?php
                if($login){
                    echo "<a id='loginAnchor' class='off'>Login</a>";
                    echo "<a id='logoutAnchor' href=logout.php class='on'>Logout</a>";
                }else{
                    echo "<a id='loginAnchor' class='on'>Login</a>";
                    echo "<a id='logoutAnchor' href=logout.php class='off'>Logout</a>";
                }
            ?>
        </li>
        <li>        
            <a <?php if(isset($_SESSION['email'])){ echo "href='edit_account.php'";}?> class="<?php if(!(isset($_SESSION['email']))){ echo "accountAnchor";}?>">Edit Account</a>
        </li>
        <li>        
            <a <?php if(isset($_SESSION['email'])){ echo "href='edit_reservation.php'";}?> class="<?php if(!(isset($_SESSION['email']))){ echo "reservationAnchor";}?>">Edit Reservation</a>
        </li>
    </ul>
    <div id="hbContainer">
        <div class="hbIcon">
            <div class="stripe1"></div>
            <div class="stripe2"></div>
            <div class="stripe3"></div>
        </div> 
    </div>
    <ul id="hbPopUp">
        <li>        
            <a href="index.php">Home</a>
        </li>
        <li>        
            <a href="food.php">Explore Food</a>
        </li>
        <li>        
            <a <?php if(isset($_SESSION['email'])){ echo "href='outlet.php'";}?> class="<?php if(!(isset($_SESSION['email']))){ echo "outletAnchor";}?>">Outlets</a>
        </li>
        <li>        
            <a href="about.php">About</a>
        </li>
        <li>        
            <a href="contact.php">Contact</a>
        </li>
        <li>        
        <a <?php if(isset($_SESSION['email'])){ echo "href='edit_reservation.php'";}?> class="<?php if(!(isset($_SESSION['email']))){ echo "reservationAnchor";}?>">Edit Reservation</a>
        </li>
        <li>        
            <a <?php if(isset($_SESSION['email'])){ echo "href='edit_account.php'";}?> class="<?php if(!(isset($_SESSION['email']))){ echo "accountAnchor";}?>">Edit Account</a>
        </li>
        <li>
            <img id="popUpLogo" src="img/logo.png" alt="logo"> 
        </li>
    </ul>
</header>

<section class="accPanel">
    <form class="accForm" action="login_process.php" method="post">
        <h2 class="accTitle">Login</h2>
        <div class="accCont">
            <label class="accLBL">UserID : </label>
            <input class="accInt" type=text name="userID">
        </div>
        <div class="accCont">
            <label class="accLBL">Password : </label>
            <input class="accInt" type=password name="password">
        </div>
        <label class="errMsg" id=loginError></label>
        <a class="openRegister">Open Register</a>
        <div class="btnCont">
        <input type=submit value="Submit" class="accButton"> 
        </div>
    </form>
    <button class="exitButton">X</button>
</section>
<section class="registerPanel">
    <form id="registerFormValid" class="accForm" action="register_process.php" method="post" style="height:100%;">
        <h2 class="accTitle">Register</h2>
        <div class="accCont">
            <label class="accLBL">UserID : </label>
            <input class="accInt" type=text name=userID id=userID>
            <label class="errMsg" id=userIDError></label>
        </div>
        <div class="accCont">
            <label class="accLBL">Name : </label>
            <input class="accInt" type=text name=name id=name>
            <label class="errMsg" id=nameError></label>
        </div>
        <div class="accCont">
            <label class="accLBL">Email : </label>
            <input class="accInt" type=text name=email id=email>
            <label class="errMsg" id=emailError></label>
        </div>
        <div class="accCont">
            <label class="accLBL">Phone : </label>
            <input class="accInt" type=text name=phone id=phone>
            <label class="errMsg" id=phoneError></label>
        </div>
        <div class="accCont">
            <label class="accLBL">Add a Favorite : </label>
            <textarea class="accInt" name=favor id=favor rows="4" cols="50"></textarea>
            <label class="errMsg" id=favorError></label>
        </div>
        <div class="accCont">
            <label class="accLBL">Password : </label>
            <input class="accInt" type=password name=password id=password>
            <label class="errMsg" id=passError></label>
        </div>
        <div class="accCont">
            <label class="accLBL">Confirm Password : </label>
            <input class="accInt" type=password name=c_password id=c_password>
            <label class="errMsg"></label></div>
        <a class="openLogin">Open Login</a>
        <input type=submit value="Submit" class="accButton"> 
    </form>
    <button class="exitButton">X</button>
</section>
<div id="backgroundTint"></div>
<script src="js/jquery.js"></script>
<script src="js/header.js"></script>
<script src="js/registerValidation.js"></script>
<script>
    <?php
        if(isset($_GET['error'])){
            if($_GET['error'] == 10001 || $_GET['error'] == 20001){
                echo "document.getElementById('loginError').innerHTML = 'Email or Password is invalid, try again!';";
                echo "console.log('login Displayed');";
                echo "showLogin();";
            }
            if($_GET['error'] == 50001){
                echo "document.getElementById('emailError').innerHTML = 'Email has been taken, try again!';";
                echo "console.log('register Displayed');";
                echo "showRegister();";
            }
            if($_GET['error'] == 60001){
                echo "document.getElementById('userIDError').innerHTML = 'USERID has been taken, try again!';";
                echo "console.log('register Displayed');";
                echo "showRegister();";
            }
        }
    ?>
</script>
