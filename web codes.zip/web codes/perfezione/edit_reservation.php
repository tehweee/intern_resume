<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Reservation</title>
    <link rel=stylesheet href="css/css_reset.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400..900&display=swap" rel="stylesheet">
    <link rel=stylesheet href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/common.css">
    <link rel=stylesheet href="css/edit_reservation.css">
</head>
<body>
    <?php include("header.php");
    require_once('dbinfo.php');
    require_once('commonFunction.php');

    session_start();
    
    /*
    $sql = "SELECT * FROM reservations WHERE userIDFK = '".$_SESSION['userID']."'";
    $results = $mysqli->query($sql);
    */
    
    $sql = "SELECT * FROM reservations WHERE userIDFK = ?";
    $queryStatement = mysqli_prepare($connection,$sql);
    mysqli_stmt_bind_param($queryStatement,'s',$_SESSION['userID']);
    mysqli_stmt_execute($queryStatement);

    mysqli_stmt_store_result($queryStatement);
    $count = mysqli_stmt_num_rows($queryStatement);
    mysqli_stmt_bind_result($queryStatement,$userIDFK,$outletIDFK,$d,$time,$noG,$VIP,$notes);

    ?>

    <main>
        <h1 id="editTitle">Edit Reservation</h1>
        <div id="outletContainer">
            <?php 
            
            if($count > 0){
                
            while(mysqli_stmt_fetch($queryStatement)){
                /*
                                    $location = "SELECT * FROM outlets WHERE outletID = '".$result['outletIDFK']."'";
                                    $locationResults = $mysqli->query($location);
                                    $locationResult = $locationResults->fetch_assoc();
                                    */
                                    $location = "SELECT * FROM outlets WHERE outletID = ?";
                                    $queryStatement5 = mysqli_prepare($connection,$location);
                                    $outletIDFK = sanitized($outletIDFK);
                                    mysqli_stmt_bind_param($queryStatement5,'s',$outletIDFK);
                                    mysqli_stmt_execute($queryStatement5);
                                    mysqli_stmt_store_result($queryStatement5);
                                    mysqli_stmt_bind_result($queryStatement5,$outletID,$locationSet,$a,$max,$VIPROOM,$img);
                                    mysqli_stmt_fetch($queryStatement5);
                                    $date = strtotime($d);
                                    $now = time(); 
                                    $daysDiff = round(($now - $date) / (60 * 60 * 24)); 
                                    $allowDelete = true;
                                    if ($daysDiff <= -2){
                                        $allowDelete = true;
                                    }else{
                                        $allowDelete = false;
                                    }
                                  
            

            ?>
            <section id="indiOutlet">
                    <img id="outletImage" src="img/<?php echo $img?>" alt="outlet_image">
                    <form id="outletDetail" action ="remove_reservation_process.php" method="post">
                        <h2 id="locationTitle"><?php 
                        echo $locationSet;
                        ?></h2>
                        <div id="outletFeatures">
                            <div class="left_col">
                                <div id="seat">Date: <?php echo $d?></div>
                                <div id="vip">No Of Guest: <?php echo $noG?></div>
                            </div>
                            <div class="right_col">
                                <div id="dining">Time: <?php echo $time?></div>
                                <div id="maxGuest">VIP Room Status: <?php if($VIP){echo "Yes";}else{echo "No";}?></div>
                            </div>
                        </div>
                        <div id="reservationBTN"><button <?php if(!($allowDelete)){echo "disabled";}?>>Remove Reservation</button></div>
                        <input type=radio name="outletID" value="<?php echo $outletID?>" checked style="display:none;">
                        <input type=radio name="userID" value="<?php echo $userIDFK?>" checked style="display:none;">
                        <input type=radio name="date" value="<?php echo $d?>" checked style="display:none;">
                        <input type=radio name="time" value="<?php echo $time?>" checked style="display:none;">
                    </form>
            </section>
                <hr>
                <?php 
                }}else{
                    echo 
                    "<form action='outlet.php' id='goOutlet'>
                    <span>You have book any outlet yet!</span>
                    <span>Feel free to click the button below to go book an outlet!</span>
                    <button>Go to Outlet</button></form>";
                }
                ?>
  
            </div>
    </main>

    <?php include("footer.php")?>
</body>
</html>