<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel=stylesheet href="css/css_reset.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400..900&display=swap" rel="stylesheet">
    <link rel=stylesheet href="css/contact.css">
    <link rel=stylesheet href="css/header.css">
    <link rel=stylesheet href="css/footer.css">
    <link rel="stylesheet" href="css/common.css">

</head>
<body>
    <?php 
    include("header.php");
    require_once('dbinfo.php');
    ?>
    <main id="contact">
        <section id="contactInfo">
            <h2 id="contactTitle">Contact Info</h2>
            <div id="contactDetailContainer">
                <article id="left_col">
                    <div>
                        <h2 class="text">Headquarter:</h2>
                        <ul>
                            <li class="text">456 Culinary Avenue, <br>Gourmet City, CA 90210, <br>USA</li>
                        </ul>  
                    </div>
                    <div>
                        <label class="text">Restaurant Number : <br>4723 1841</label><br>
                        <label class="text">Reception Number : <br>9713 8193</label><br>
                        <label class="text">Chef Number : <br>9713 8193</label><br>
                    </div>
                    <label class="text">Business Email : contact@perfezione.com</label>
                </article>
                <article id="right_col">
                    <h2 class="text">Restaurant Owner:<br>Pang Teh Wee</h2>
                    <ul>
                        <li class="text">Open Everyday <br>(Do note some restaurant might be close)</li>
                        <li>
                            <h2 class="text">LUNCH:</h2>
                            <ul>
                                <li class="text">12:00pm to 2:00pm</li>
                            </ul>
                        </li>
                        <li>
                            <h2 class="text">DINNER:</h2>
                            <ul>
                                <li class="text">6:00pm to 8:00pm</li>
                            </ul>
                        </li>
                    </ul>
                </article>
            </div>
            <a class="button" href="contactForm.php">Go Contact Form</a>
        </section>
        <?php         
        $sql = "SELECT * FROM foods ORDER BY RAND() LIMIT 1;";
        $result = (($mysqli->query($sql)) -> fetch_assoc());
        ?>
        <img id="contactImage" src="img/<?php echo $result['rightPic']?>" alt="contact_image">
    </main>
    <?php include("footer.php")?>
</body>
</html>