<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel=stylesheet href="css/css_reset.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400..900&display=swap" rel="stylesheet">
    <link rel=stylesheet href="css/edit_account.css">
    <link rel=stylesheet href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/common.css">
    <style>

    </style>
</head>
<body>
    <?php 
    include("header.php");
    require_once("dbinfo.php");
    require_once('commonFunction.php');
    session_start();
    $emailWarning = "";
    $userIDWarning = "";

    /*
    $sql = "SELECT * FROM users WHERE userID = '".$_SESSION['userID']."'";
    $result = ($mysqli->query($sql))->fetch_assoc();
    */
    $sql = "SELECT * FROM users WHERE userID = ?";
    $queryStatement = mysqli_prepare($connection,$sql);
    $_SESSION['userID'] = sanitized($_SESSION['userID']);
    mysqli_stmt_bind_param($queryStatement,'s',$_SESSION['userID']);
    mysqli_stmt_execute($queryStatement);
    mysqli_stmt_store_result($queryStatement);
    $count = mysqli_stmt_num_rows($queryStatement);
    mysqli_stmt_bind_result($queryStatement,$uID,$e,$hp,$n,$p,$pfp,$cp,$f);
    mysqli_stmt_fetch($queryStatement);


    if(isset($_POST['userIDUpdate'])){
        $userIDWarning = "";

        /*
        $compare = "SELECT * FROM users WHERE userID = '".$_POST['userIDUpdate']."'";
        */
        $compare = "SELECT * FROM users WHERE userID = ?";
        $queryStatement = mysqli_prepare($connection,$compare);
        $_POST['userIDUpdate'] = sanitized($_POST['userIDUpdate']);
        mysqli_stmt_bind_param($queryStatement,'s',$_POST['userIDUpdate']);
        mysqli_stmt_execute($queryStatement);
        mysqli_stmt_store_result($queryStatement);
        $count = mysqli_stmt_num_rows($queryStatement);

            if($count > 0){
                $userIDWarning = "USERID has been repeated, please try again!";
            }else{
                $userIDWarning = "";
                $_SESSION['userID'] = $_POST['userIDUpdate'];

                /*
                $update = "UPDATE users SET userID = '".$_POST['userIDUpdate']."' WHERE userID='".$uID."';";
                $mysqli->query($update);
                $update = "UPDATE reservations SET userIDFK = '".$_POST['userIDUpdate']."' WHERE userIDFK ='".$uID."';";
                $mysqli->query($update);
                */
                
                $update = "UPDATE users SET userID = ? WHERE userID=?";
                $queryStatement = mysqli_prepare($connection,$update);
                $_POST['userIDUpdate'] = sanitized($_POST['userIDUpdate']);
                $uID = sanitized($uID);
                mysqli_stmt_bind_param($queryStatement,'ss',$_POST['userIDUpdate'],$uID);
                mysqli_stmt_execute($queryStatement);
                $update = "UPDATE reservations SET userIDFK = ? WHERE userIDFK =?";
                $queryStatement = mysqli_prepare($connection,$update);
                $_POST['userIDUpdate'] = sanitized($_POST['userIDUpdate']);
                $uID = sanitized($uID);
                mysqli_stmt_bind_param($queryStatement,'ss',$_POST['userIDUpdate'],$uID);
                mysqli_stmt_execute($queryStatement);
                

            }
    }
    if(isset($_POST['emailUpdate'])){
        $userIDWarning = "";
        /*
        $compare = "SELECT * FROM users WHERE email = '".$_POST['emailUpdate']."'";
        */
        $compare = "SELECT * FROM users WHERE email = ?";
        $queryStatement = mysqli_prepare($connection,$compare);
        $_POST['emailUpdate'] = sanitized($_POST['emailUpdate']);
        mysqli_stmt_bind_param($queryStatement,'s',$_POST['emailUpdate']);
        mysqli_stmt_execute($queryStatement);
        mysqli_stmt_store_result($queryStatement);
        $count = mysqli_stmt_num_rows($queryStatement);

            if($count > 0){
                $userIDWarning = "Email has been repeated, please try again!";
            }else{
                $userIDWarning = "";
                $_SESSION['email'] = $_POST['emailUpdate'];

                /*
                $update = "UPDATE users SET email = '".$_POST['emailUpdate']."' WHERE email='".$result['email']."';";
                $mysqli->query($update);
                $update = "UPDATE contact SET email = '".$_POST['emailUpdate']."' WHERE email ='".$result['email']."';";
                $mysqli->query($update);
                */

                $update = "UPDATE users SET email = ? WHERE email=?";
                $queryStatement = mysqli_prepare($connection,$update);
                $_POST['emailUpdate'] = sanitized($_POST['emailUpdate']);
                $e = sanitized($e);
                mysqli_stmt_bind_param($queryStatement,'ss',$_POST['emailUpdate'],$e);
                mysqli_stmt_execute($queryStatement);
                $update = "UPDATE contact SET email = ? WHERE email =?";
                $queryStatement = mysqli_prepare($connection,$update);
                $_POST['emailUpdate'] = sanitized($_POST['emailUpdate']);
                $e = sanitized($e);
                mysqli_stmt_bind_param($queryStatement,'ss',$_POST['emailUpdate'],$e);
                mysqli_stmt_execute($queryStatement);
            }
    }
    if(isset($_POST['nameUpdate'])){
        $_SESSION['name'] = $_POST['nameUpdate'];

        /*
        $update = "UPDATE users SET name = '".$_POST['nameUpdate']."' WHERE name='".$result['name']."';";
        $mysqli->query($update);
        $update = "UPDATE contact SET name = '".$_POST['nameUpdate']."' WHERE name='".$result['name']."';";
        $mysqli->query($update);
        */

        $update = "UPDATE users SET name = ? WHERE name=?";
        $queryStatement = mysqli_prepare($connection,$update);
        $_POST['nameUpdate'] = sanitized($_POST['nameUpdate']);
        $n = sanitized($n);
        mysqli_stmt_bind_param($queryStatement,'ss',$_POST['nameUpdate'],$n);
        mysqli_stmt_execute($queryStatement);
        $update = "UPDATE contact SET name = ? WHERE name=?";
        $queryStatement = mysqli_prepare($connection,$update);
        $_POST['nameUpdate'] = sanitized($_POST['nameUpdate']);
        $n = sanitized($n);
        mysqli_stmt_bind_param($queryStatement,'ss',$_POST['nameUpdate'],$n);
        mysqli_stmt_execute($queryStatement);

    }

    if(isset($_POST['phoneUpdate'])){
        $_SESSION['phoneNumber'] = $_POST['phoneUpdate'];
        /*
        $update = "UPDATE users SET phoneNumber = '".$_POST['phoneUpdate']."' WHERE phoneNumber='".$result['phoneNumber']."';";
        $mysqli->query($update);
        $update = "UPDATE contact SET phoneNumber = '".$_POST['phoneUpdate']."' WHERE phoneNumber='".$result['phoneNumber']."';";
        $mysqli->query($update);
        */
        $update = "UPDATE users SET phoneNumber = ? WHERE phoneNumber=?";
        $queryStatement = mysqli_prepare($connection,$update);
        $_POST['phoneUpdate'] = sanitized($_POST['phoneUpdate']);
        $hp = sanitized($hp);
        mysqli_stmt_bind_param($queryStatement,'ss',$_POST['phoneUpdate'],$hp);
        mysqli_stmt_execute($queryStatement);
        $update = "UPDATE contact SET phoneNumber = ? WHERE phoneNumber=?";
        $queryStatement = mysqli_prepare($connection,$update);
        $_POST['phoneUpdate'] = sanitized($_POST['phoneUpdate']);
        $hp = sanitized($hp);
        mysqli_stmt_bind_param($queryStatement,'ss',$_POST['phoneUpdate'],$hp);
        mysqli_stmt_execute($queryStatement);
    }


    /*
    $sql = "SELECT * FROM users WHERE email = '".$_SESSION['email']."'";
    $result = ($mysqli->query($sql))->fetch_assoc();
    */
    $sql = "SELECT * FROM users WHERE email = ?";
    $queryStatement = mysqli_prepare($connection,$sql);
    $_SESSION['email'] = sanitized($_SESSION['email']);
    mysqli_stmt_bind_param($queryStatement,'s',$_SESSION['email']);
    mysqli_stmt_execute($queryStatement);
    mysqli_stmt_store_result($queryStatement);
    mysqli_stmt_bind_result($queryStatement,$uID,$e,$hp,$n,$p,$pfp,$cp,$f);

    ?>
    <main>
        <section id="editPanel">
            <div class="label_a" style="margin-bottom:80px">
                <?php
                /*
                $getImage = "SELECT profilePic FROM users WHERE  userID = '".$_SESSION['userID']."'";
                $image = $mysqli->query($getImage)->fetch_assoc();
                */
                
                $getImage = "SELECT profilePic FROM users WHERE  userID = ?";
                $queryStatement = mysqli_prepare($connection,$getImage);
                $_SESSION['userID'] = sanitized($_SESSION['userID']);
                mysqli_stmt_bind_param($queryStatement,'s',$_SESSION['userID']);
                mysqli_stmt_execute($queryStatement);
                mysqli_stmt_store_result($queryStatement);
                mysqli_stmt_bind_result($queryStatement,$profilePic);
                
                $imagePath = "profilePic/".$pfp;
                ?>
            <img style="width:80px;height:80px;border-radius:50%;" <?php
            echo "src = '".$imagePath."'"
            ?>>
            </div>
            <div class="label_a" style="margin-bottom:80px">
                <form id="login-form" method="post" action="uploadPfp.php" enctype="multipart/form-data" style="width:100%;display:flex;
                flex-direction:row;justify-content:space-between;align-items: center;">
                    <input name="user_profile" type="file" id="user_profile" style="font-family:'Montserrat', sans-serif;"></input>
                    <input class="button" type="submit" value="Submit" style="  padding:15px 20px;
                                                                                font-family: 'Montserrat', sans-serif;
                                                                                font-optical-sizing: auto;
                                                                                font-style: normal;
                                                                                width:100px;"/>
                </form>
            </div>
            <div class="label_a">
                    <div class="infoContainer">
                        <div class="promptContainer">
                            <div class="userIDHolder">UserID : 
                                <label id="userIDDisplay"><?php echo $uID?></label>
                                <form id="userIDPrompt" action="edit_account.php" method="post">
                                    <input type=text name="userIDUpdate" id="userIDUpdate">
                                </form>
                            </div>
                        </div>
                        <label id="userIDErr" class="err"><?php echo $userIDWarning;?></label>
                    </div>
                    <a id="changeUserID">change</a>
            </div>

            <div class="label_a">
                <div class="infoContainer">
                    <div class="promptContainer">
                        <div class="nameHolder">Name : 
                            <label id="nameDisplay"><?php echo $n?></label>
                            <form id="namePrompt" action="edit_account.php" method="post">
                                <input type=text name="nameUpdate" id="nameUpdate">
                            </form>
                        </div>
                    </div>
                    <label id="nameErr" class="err"></label>
                </div>
                <a id="changeName">change</a>
            </div>

            <div class="label_a">
                <div>
                    <div class="promptContainer">
                            <div class="emailHolder">Email : <label id="emailDisplay"><?php echo $e?></label>
                        <form id="emailPrompt" action="edit_account.php" method="post">
                            <input type=text name="emailUpdate" id="emailUpdate">
                        </form>
                    </div>
                    </div>
                    <label id="emailErr" class="err"><?php echo $emailWarning;?></label>
                </div>
                <a id="changeEmail">change</a>
            </div>

            <div class="label_a">
                <div>
                    <div class="promptContainer">
                        <div class="phoneHolder">Phone Number : <label id="phoneDisplay"><?php echo $hp?></label>
                    <form id="phonePrompt" action="edit_account.php" method="post">
                        <input type=text name="phoneUpdate" id="phoneUpdate">
                    </form>
                </div>
                    </div>
                    <label id="phoneErr" class="err"></label>
                </div>
                <a id="changePhone">change</a>
            </div>
            
            <div class="label_a">
                <div style="display:none;">
                    <div class="promptContainer">
                        <div class="phoneHolder">Password : <label id="passDisplay">***</label>
                    <form id="passPrompt" action="edit_account.php" method="post">
                        <input type=text name="passUpdate" id="passUpdate">
                    </form>
                </div>
                    </div style="display:none;">
                    <label style="display:none;" id="passErr" class="err"></label>
                </div>
                <a style="display:none;" id="changePass">change</a>
            </div>
            <div class="label_a">
                        <div class="phoneHolder">Favorite : <label id="passDisplay"><?php echo $f?></label></div>
            </div>



            <form id="accDelPanel" action="remove_account.php">
                <h2>Delete Account</h2>
                <label>WARNING : Do note that deletion of the account will be pernament</label>
                <button>Delete Account</button>
            </form>
        </section>
    </main>
    <?php include("footer.php")?>
    <script src="js/edit_account.js"></script>
</body>
</html>