<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel=stylesheet href="css/css_reset.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400..900&display=swap" rel="stylesheet">
    <link rel=stylesheet href="css/reservation_page.css">
    <link rel=stylesheet href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/common.css">
</head>
<body>
    <?php 
    include("header.php");
    ?>
    <?php
        require_once('dbinfo.php');
        require_once('commonFunction.php');

      /*
        $sql = "SELECT * FROM outlets WHERE outletID = ".$_GET['outletid']."";

        $results = $mysqli->query($sql);
        $result = $results->fetch_assoc();
        */
        $sql = "SELECT * FROM outlets WHERE outletID = ?";
        $queryStatement = mysqli_prepare($connection,$sql);
        $_GET['outletid'] = sanitized($_GET['outletid']);
        mysqli_stmt_bind_param($queryStatement,'s',$_GET['outletid']);
        mysqli_stmt_execute($queryStatement);
        mysqli_stmt_store_result($queryStatement);
        mysqli_stmt_bind_result($queryStatement,$outletID,$location,$availability,$maxGuest,$VIPRoom,$outletImg);
        mysqli_stmt_fetch($queryStatement);
    ?>
    <main id="reservationMain">
        <section id="reservationContainer">
            <img id="reservationImg" src="img/<?php echo $outletImg;?>" alt="reservation_image">
            <div id="reservationInfo">
                <h1 id="reservationTitle"><?php echo $location?></h1>
                <p class=outletInfo>Outlet info :</p>
                <div id="reservationSpecs">
                    <div class="left_col">
                            <div id="seat">Restaurant Status: <?php if($availability){echo "Available";}else{echo "Unavailable";}?></div>
                            <div id="vip">VIP Room Status: <?php if($VIPRoom){echo "Available";}else{echo "Unavailable";}?></div>
                        </div>
                        <div class="right_col">
                            <div id="dining">Dining Timing: <?php 
                                                        /*
                                                         $timeSQL = "SELECT diningTime FROM diningtime WHERE outletID = '".$outletID."'";
                                                         $timeresults = $mysqli->query($timeSQL);
                                                         while($timeresult = $timeresults->fetch_assoc()){
                                                             echo $timeresult['diningTime'].",";
                                                         }
                                                             */
                                                            $timeSQL = "SELECT diningTime FROM diningtime WHERE outletID = ?";
                                                            $queryStatement5 = mysqli_prepare($connection,$timeSQL);
                                                            $outletID = sanitized($outletID);
                                                            mysqli_stmt_bind_param($queryStatement5,'s',$outletID);
                                                            mysqli_stmt_execute($queryStatement5);
                                                            mysqli_stmt_bind_result($queryStatement5,$diningTime);
                                                            while(mysqli_stmt_fetch($queryStatement5)){
                                                                echo $diningTime.",";
                                                            }
                                                         ?></div>
                            <div id="maxGuest">Max no of Guest: <?php echo $maxGuest;?></div>
                        </div>
                    </div>
                </div>
        </section>
        <form id="reservationForm" action="reservation_process.php?outletid=<?php echo $outletID?>" method=post>
            <div>
                <label>Booking Date: </label>
                <input type=date name=dateInput id=dateInput class=dateInput>
                <label id="reservationErrDate"></label>
            </div>
            <div>
                <label>Booking Time: </label>
                <select id="dine" name="dine" class=dine>
                <?php
                /*
                $timeSQL = "SELECT diningTime FROM diningtime WHERE outletID = '".$outletID."'";
                $timeresults = $mysqli->query($timeSQL);
                $yes = true;
                while($timeresult = $timeresults->fetch_assoc()){ 
                */
                $timeSQL = "SELECT diningTime FROM diningtime WHERE outletID = ?";
                $queryStatement6 = mysqli_prepare($connection,$timeSQL);
                $outletID = sanitized($outletID);
                mysqli_stmt_bind_param($queryStatement6,'s',$outletID);
                mysqli_stmt_execute($queryStatement6);
                $yes = true;
                mysqli_stmt_bind_result($queryStatement6,$diningTime);
                while(mysqli_stmt_fetch($queryStatement6)){
                    ?>
                    <option value="<?php echo $diningTime?>" <?php if($yes){echo "selected";$yes=false;}?>>
                        <?php 
                        if($diningTime == "12:00-2:00"){
                            echo "Lunch ";
                        }else{
                            echo "Dinner ";
                        }
                        echo $diningTime;
                        ?></option>
                    <?php }?>
                </select>
            </div>
            <div class="radio">
                <label>VIP Room: </label>
                <label for="yes">Yes </label>
                <input type="radio" id="yes" name="viproom" value="1" <?php if(!($VIPRoom)){echo "disabled";}?>>
                <label for="no">No </label>
                <input type="radio" id="no" name="viproom" value="0" checked>
            </div>
            <div>
                <label>Number of Guest: </label>
                <select id="nog" name="nog" class=nog>
                    <?php for($i = 1; $i < $maxGuest+1;$i++){?>
                    <option value="<?php echo $i?>"><?php echo $i?></option>
                    <?php }?>
                </select>            
            </div>
            <div class=feedbackContainer>
                <label>Feedback:</label>
                <textarea name=noteInput id=noteInput class=noteInput></textarea>
                <label id="reservationErrFeedback"></label>
            </div>
            <input type=submit class=button id=submitReservation>
        </form>
    </main>
    <?php include("footer.php")?>
    <script>
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('dateInput').setAttribute('min', today);
        feedback = document.getElementById('noteInput');
        document.getElementById('reservationForm').addEventListener("submit",function(event) {
            event.preventDefault();
            document.getElementById('reservationErrFeedback').innerHTML = "";
            document.getElementById('reservationErrDate').innerHTML = "";
            if(document.getElementById('dateInput').value){
                if(feedback.value.length == 0){ 
                document.getElementById('reservationErrFeedback').innerHTML = "You have not selected a date, try again!";
                }else{
                    this.submit();
                }
            }else{
                document.getElementById('reservationErrDate').innerHTML = "You have not enter a feedback, try again!";
            }
        });
    </script>
</body>
</html>