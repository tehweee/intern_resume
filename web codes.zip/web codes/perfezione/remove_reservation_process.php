<?php
    include("dbinfo.php");
    require_once('commonFunction.php');

    /*
    $sql = "DELETE FROM reservations WHERE userIDFK = '".$_POST['userID']."' && 
    outletIDFK = '".$_POST['outletID']."' && date='".$_POST['date']."' && time = '".$_POST['time']."'";
    $results = $mysqli->query($sql);
    */

    $sql = "DELETE FROM reservations WHERE userIDFK = ? && 
    outletIDFK = ? && date=? && time = ?;";
    $queryStatement = mysqli_prepare($connection,$sql);
    $_POST['userID'] = sanitized($_POST['userID']);
    $_POST['outletID'] = sanitized($_POST['outletID']);
    $_POST['date'] = sanitized($_POST['date']);
    $_POST['time'] = sanitized($_POST['time']);
    mysqli_stmt_bind_param($queryStatement,'ssss',$_POST['userID'],$_POST['outletID'],$_POST['date'],$_POST['time']);
    mysqli_stmt_execute($queryStatement);
    header("Location: remove_reservation_confirm.php");
?>