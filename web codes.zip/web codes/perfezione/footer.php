
<footer id="footerNav">
        <div id="mainFooter">
            <div id="CTAs"> 
                <div id="footer_main_cta">
                    <a class="footer_cta" href="index.php">Home</a>
                    <a class="footer_cta" href="contact.php">Contact Info</a>
                    <a class="footer_cta" href="food.php">View Food</a>
                    <a class="footer_cta" href="about.php">Learn More</a>
                </div>
            </div>
            <div id="footerLogo">
                <a href="index.php"><img src="img/logo.png" alt="logo"></a>
            </div>
        </div>
        <h2 id="copyright">
            Pang Teh Wee All &copy; copyright reserved
    </h2>
</footer>