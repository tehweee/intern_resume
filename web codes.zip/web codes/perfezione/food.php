<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel=stylesheet href="css/css_reset.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400..900&display=swap" rel="stylesheet">
    <link rel=stylesheet href="css/food.css">
    <link rel=stylesheet href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/common.css">
</head>
<body>
    <?php 
    include("header.php");
    require_once("dbinfo.php");
    require_once('commonFunction.php');

    $sql = "SELECT * FROM foodcategory";
    $results = $mysqli->query($sql);
    ?>

    <main>
        <?php while($result = $results->fetch_assoc()){?>
        <div class="foodCategory">
            <div class="titleContainer">
                <hr>
                <h1>"<?php echo $result['categoryName']?>"</h1>
                <hr>
            </div>
            <?php 
            /*
            $sqlFood = "SELECT * FROM foods WHERE categoryIDFK = '".$result['categoryID']."'";
            $foodResults = $mysqli->query($sqlFood);
            */
            $sqlFood = "SELECT * FROM foods WHERE categoryIDFK = ?";
            $queryStatement = mysqli_prepare($connection,$sqlFood);
            $result['categoryID'] = sanitized($result['categoryID']);
            mysqli_stmt_bind_param($queryStatement,'s',$result['categoryID']);
            mysqli_stmt_execute($queryStatement);

            mysqli_stmt_store_result($queryStatement);
            mysqli_stmt_bind_result($queryStatement,$foodID,$categoryIDFK,$foodName,$foodDescription,$leftPic,$rightPic);

            while(mysqli_stmt_fetch($queryStatement)){
            ?>
            <div class="foodDisplay">
                <img class="imgleft" src="img/<?php echo $leftPic?>" alt="img_left">
                <section class="foodInfo">
                    <h2 class="foodName"><?php echo $foodName?></h2>
                    <p class="foodDescription"><?php echo $foodDescription?></p>
                </section>
                <img class="imgright" src="img/<?php echo $rightPic?>" alt="img_right">
            </div>
            <?php }?>
        </div>
        <?php }?>
    </main>

    <?php include("footer.php")?>
</body>
</html>