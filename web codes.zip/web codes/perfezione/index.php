<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel=stylesheet href="css/css_reset.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400..900&display=swap" rel="stylesheet">
    <link rel=stylesheet href="css/index.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/common.css">
</head>
<body>
    <?php 
    include("header.php");
    require_once('dbinfo.php');
    $sql = "SELECT * FROM homepageinfo";
    $result = ($mysqli->query($sql))->fetch_assoc();
    ?>
    <nav id="heroBanner">
        <h1><?php echo $result['title']?></h1>
        <a class="heroCTA" href="<?php echo $result['cta']?>">click on the hero to view</a>
        <img src="img/<?php echo $result['heroImg']?>" alt="hero_image">
    </nav>
    <main>
        <section id="descriptionSection">
            <h1 class="title aboutTitle">Our Journey</h1>
            <div class="contentContainer">
                <div class="image aboutImage"><img src="img/<?php echo $result['aboutImg']?>" alt="about_image"></div>
                <div class="textContainer">
                    <p class="description aboutDes">
                        <?php echo $result['aboutDescription']?>
                    </p>
                    <div class="buttonContainer">
                        <a href="about.php" class="button">Explore About Us</a>
                    </div>
                </div>
            </div>
        </section>

        <hr>
        <?php
            $displaySQL = "SELECT * 
                            FROM foods
                            ORDER BY RAND()
                            LIMIT 10;";
            $displayresults = $mysqli->query($displaySQL);
            $count = 0;
        ?>
        <div id="courseDisplaySection">
            <div id="grid">
                <div class="foodDisplayTitle">Explore Wonders</div>
                <?php
                    while($displayresult = $displayresults->fetch_assoc()){
                        $count++;
                ?>
                <img class="box box<?php echo $count?>" src="img/<?php echo $displayresult['leftPic']?>" alt="grid_image">
                <?php }?>
            </div>
            <div class="buttonContainer">
                    <?php     
                        $login = false;
                        if(isset($_SESSION['name'])){
                            $login = true;
                        }
                    ?>
                        <a href="outlet.php" class="button" <?php if(!$login){echo "onclick='return false;' style='color:lightgray'";}?>>
                        View Outlet
                    </a>
                    <a href="food.php" class="button">View Menu</a>
            </div>
        </div>

        <hr>

        <section id="detailSection">
            <h1 class="title detailTitle">Contact Now</h1>
            <div class="contentContainerRes">
                <div class="resContainer">
                    <p class="description resDes">
                        <?php echo $result['contactDescription']?>
                    </p>
                    <div class="buttonContainer resBTN">
                        <a href="contact.php" class="button">Explore Contact Us</a>
                    </div>
                </div>
                <div class="image aboutImage"><img src="img/<?php echo $result['contactImg']?>" alt="contact_image"></div>
            </div>
        </section>
    </main>
    <?php include("footer.php")?>
</body>
</html>