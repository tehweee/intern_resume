<?php
    require_once("dbinfo.php");
    require_once('commonFunction.php');
    session_start();
    try{
        /*
        $sql = "INSERT INTO reservations 
        VALUES (
        '".$_SESSION['userID']."',
        '".$_GET['outletid']."',
        '".$_POST['dateInput']."',
        '".$_POST['dine']."',
        ".$_POST['nog'].",
        '".$_POST['viproom']."',
        '".$_POST['noteInput']."')";
        $results = $mysqli->query($sql);
        */
        $sql = "INSERT INTO reservations 
        VALUES (?,?,?,?,?,?,?)";        
        $queryStatement = mysqli_prepare($connection,$sql);
        $_SESSION['userID'] = sanitized($_SESSION['userID']);
        $_GET['outletid'] = sanitized($_GET['outletid']);
        $_POST['dateInput'] = sanitized($_POST['dateInput']);
        $_POST['dine'] = sanitized($_POST['dine']);
        $_POST['nog'] = sanitized($_POST['nog']);
        $_POST['viproom'] = sanitized($_POST['viproom']);
        $_POST['noteInput'] = sanitized($_POST['noteInput']);
        mysqli_stmt_bind_param($queryStatement,'sssssss',$_SESSION['userID'],
        $_GET['outletid'],$_POST['dateInput'],
        $_POST['dine'],$_POST['nog'],
        $_POST['viproom'],$_POST['noteInput']);
        
        if(mysqli_stmt_execute($queryStatement)){
            header("Location: reservation_confirm.php");
        }
    }catch(mysqli_sql_exception){
        echo "    
        <link rel=stylesheet href='css/reservation_confirm.css'>
        <link rel='stylesheet' href='css/common.css'>
        <main>
        <form action='index.php'>
            <img src='img/logo_head.png' class='registerLogo'>
            <h1>You have already book this before, try a different outlet!</h1>
            <button>Go Back</button>
        </form>
        </main>"
        ;
    }
?>